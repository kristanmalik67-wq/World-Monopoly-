import { create } from "zustand";
import { persist } from "zustand/middleware";
import { createGame, reduce, type Action } from "./engine.ts";
import type { GameState, SetupPlayer } from "./types.ts";

interface Store {
  game: GameState | null;
  dispatch: (action: Action) => void;
  start: (players: SetupPlayer[]) => void;
  reset: () => void;
}

export const useGame = create<Store>()(
  persist(
    (set, get) => ({
      game: null,
      dispatch: (action) => {
        const game = get().game;
        if (!game) return;
        set({ game: reduce(game, action) });
      },
      start: (players) => set({ game: createGame(players) }),
      reset: () => set({ game: null }),
    }),
    {
      name: "monopoli-dunia-v1",
      skipHydration: true,
      partialize: (store) => ({ game: store.game }),
    },
  ),
);
