export function money(n: number): string {
  const sign = n < 0 ? "−" : "";
  return `${sign}K${Math.abs(Math.round(n)).toLocaleString("id-ID")}`;
}
