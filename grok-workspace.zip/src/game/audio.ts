let context: AudioContext | null = null;
let unlocked = false;

function ctx(): AudioContext | null {
  if (!unlocked) return null;
  if (typeof window === "undefined") return null;
  if (!context) context = new AudioContext();
  if (context.state === "suspended") void context.resume();
  return context;
}

export function unlockAudio() {
  if (typeof window === "undefined") return;
  unlocked = true;
  const audio = ctx();
  if (audio?.state === "suspended") void audio.resume();
}

function tone(frequency: number, at: number, duration: number, type: OscillatorType, gain = 0.04) {
  const audio = ctx();
  if (!audio) return;
  const osc = audio.createOscillator();
  const amp = audio.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(frequency, audio.currentTime + at);
  amp.gain.setValueAtTime(gain, audio.currentTime + at);
  amp.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + at + duration);
  osc.connect(amp);
  amp.connect(audio.destination);
  osc.start(audio.currentTime + at);
  osc.stop(audio.currentTime + at + duration + 0.02);
}

export function play(kind: "dice" | "coin" | "jail" | "go" | "win" | "tap") {
  if (kind === "dice") {
    tone(180, 0, 0.08, "square", 0.03);
    tone(240, 0.09, 0.09, "square", 0.03);
    return;
  }
  if (kind === "coin") {
    tone(660, 0, 0.08, "triangle", 0.04);
    tone(880, 0.07, 0.12, "triangle", 0.04);
    return;
  }
  if (kind === "jail") {
    tone(110, 0, 0.2, "sawtooth", 0.03);
    return;
  }
  if (kind === "go") {
    tone(523, 0, 0.1, "triangle", 0.04);
    tone(659, 0.08, 0.14, "triangle", 0.04);
    return;
  }
  if (kind === "win") {
    tone(523, 0, 0.12, "triangle", 0.05);
    tone(659, 0.12, 0.12, "triangle", 0.05);
    tone(784, 0.24, 0.22, "triangle", 0.05);
    return;
  }
  tone(440, 0, 0.05, "sine", 0.03);
}
