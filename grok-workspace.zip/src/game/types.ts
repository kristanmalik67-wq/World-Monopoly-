export type CountryGroup =
  | "cokelat"
  | "biru-muda"
  | "pink"
  | "oranye"
  | "merah"
  | "kuning"
  | "hijau"
  | "biru-tua";

export type GroupId = CountryGroup | "perusahaan";

export type CompanyId = "listrik" | "air" | "internet" | "stasiun" | "pelabuhan";

export type TokenId = "plane" | "ship" | "car" | "luggage" | "globe" | "camera";

export type DeckId = "chest" | "chance";

export type SpaceKind =
  | "start"
  | "jail"
  | "parking"
  | "goto-jail"
  | "chest"
  | "chance"
  | "country"
  | "company";

export interface CountrySpace {
  index: number;
  kind: "country";
  name: string;
  short: string;
  group: CountryGroup;
  price: number;
  /** [dasar, 1 rumah, 2, 3, 4, hotel] */
  rents: [number, number, number, number, number, number];
}

export interface CompanySpace {
  index: number;
  kind: "company";
  name: string;
  short: string;
  company: CompanyId;
  price: number;
}

export interface SpecialSpace {
  index: number;
  kind: Exclude<SpaceKind, "country" | "company">;
  name: string;
  short: string;
}

export type Space = CountrySpace | CompanySpace | SpecialSpace;

export type Effect =
  | { type: "bank"; amount: number }
  | { type: "pot"; amount: number }
  | { type: "collect"; amount: number }
  | { type: "pay-each"; amount: number }
  | { type: "goto"; index: number }
  | { type: "nearest"; which: "transport" | "utility" }
  | { type: "back"; steps: number }
  | { type: "jail" }
  | { type: "jail-card" }
  | { type: "repair"; house: number; hotel: number }
  | { type: "start" };

export interface CardDef {
  id: string;
  deck: DeckId;
  title: string;
  text: string;
  effect: Effect;
}

export interface Player {
  id: string;
  name: string;
  color: string;
  token: TokenId;
  isBot: boolean;
  money: number;
  pos: number;
  inJail: boolean;
  jailTurns: number;
  jailCards: { chest: number; chance: number };
  bankrupt: boolean;
}

export interface Deed {
  ownerId: string | null;
  houses: number;
  mortgaged: boolean;
}

export interface Obligation {
  fromId: string;
  to: { type: "player"; id: string } | { type: "bank" } | { type: "pot" };
  amount: number;
  reason: string;
}

export interface Auction {
  index: number;
  bid: number;
  leaderId: string | null;
  passed: string[];
  turnId: string;
}

export interface TradeOffer {
  fromId: string;
  toId: string;
  giveMoney: number;
  takeMoney: number;
  give: number[];
  take: number[];
}

export interface Anim {
  stepsLeft: number;
  collectGo: boolean;
  backward: boolean;
  rentMul: number;
}

export interface LogLine {
  id: number;
  text: string;
  tone: "info" | "good" | "bad";
}

export type Phase =
  | "turn"
  | "jail"
  | "rolling"
  | "animating"
  | "buy"
  | "auction"
  | "card"
  | "debt"
  | "trade"
  | "gameover";

export type Resume = "finish" | "move" | "turn";

export interface GameState {
  saveVersion: 1;
  phase: Phase;
  players: Player[];
  current: number;
  deeds: (Deed | null)[];
  pot: number;
  chest: string[];
  chestDiscard: string[];
  chance: string[];
  chanceDiscard: string[];
  doubles: number;
  dice: [number, number] | null;
  anim: Anim | null;
  rentMul: number;
  card: { id: string; deck: DeckId } | null;
  obligations: Obligation[];
  auction: Auction | null;
  trade: TradeOffer | null;
  returnPhase: "turn" | "jail";
  resume: Resume;
  forceJail: boolean;
  jailedThisTurn: boolean;
  buyIndex: number | null;
  log: LogLine[];
  logId: number;
  notice: string | null;
  winnerId: string | null;
}

export interface SetupPlayer {
  name: string;
  human: boolean;
  color: string;
  token: TokenId;
}
