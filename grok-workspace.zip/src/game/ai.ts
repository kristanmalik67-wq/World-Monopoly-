import { GROUP_META, SPACES, spacePrice, unmortgageCost } from "./board.ts";
import {
  buildBlock,
  mortgageBlock,
  ownedIndexes,
  sellBlock,
  type Action,
} from "./engine.ts";
import type { GameState, Player } from "./types.ts";

function actor(state: GameState): Player | null {
  if (state.phase === "debt") {
    const due = state.obligations[0];
    if (!due) return null;
    return state.players.find((player) => player.id === due.fromId) ?? null;
  }
  if (state.phase === "auction" && state.auction) {
    return state.players.find((player) => player.id === state.auction?.turnId) ?? null;
  }
  if (state.phase === "trade" && state.trade) {
    return state.players.find((player) => player.id === state.trade?.toId) ?? null;
  }
  if (state.phase === "card" || state.phase === "turn" || state.phase === "jail" || state.phase === "buy") {
    return state.players[state.current] ?? null;
  }
  return null;
}

function completesSet(state: GameState, playerId: string, index: number): boolean {
  const space = SPACES[index];
  if (!space || (space.kind !== "country" && space.kind !== "company")) return false;
  return SPACES.every((candidate, candidateIndex) => {
    if (candidateIndex === index) return true;
    if (space.kind === "country") {
      if (candidate.kind !== "country" || candidate.group !== space.group) return true;
      return state.deeds[candidateIndex]?.ownerId === playerId;
    }
    if (candidate.kind !== "company") return true;
    return state.deeds[candidateIndex]?.ownerId === playerId;
  });
}

function wantsToBuy(state: GameState, player: Player, index: number): boolean {
  const price = spacePrice(index);
  if (price <= 0 || player.money < price) return false;
  if (completesSet(state, player.id, index)) return player.money - price >= 40;
  const reserve = 180;
  if (player.money - price < reserve && price > 160) return false;
  return player.money - price >= reserve || price <= 120;
}

function maxBid(state: GameState, player: Player, index: number): number {
  const price = spacePrice(index);
  const completes = completesSet(state, player.id, index);
  const cap = completes ? Math.floor(price * 0.95) : Math.floor(price * 0.65);
  return Math.min(cap, player.money - (completes ? 40 : 120));
}

function pickBuild(state: GameState, player: Player): number | null {
  let choice: number | null = null;
  for (const index of ownedIndexes(state, player.id)) {
    if (buildBlock(state, index)) continue;
    const space = SPACES[index];
    if (!space || space.kind !== "country") continue;
    const houses = state.deeds[index]?.houses ?? 0;
    if (houses >= 3) continue;
    if (player.money < GROUP_META[space.group].house + 280) continue;
    if (choice == null || houses < (state.deeds[choice]?.houses ?? 0)) choice = index;
  }
  return choice;
}

function pickUnmortgage(state: GameState, player: Player): number | null {
  for (const index of ownedIndexes(state, player.id)) {
    const deed = state.deeds[index];
    if (!deed?.mortgaged) continue;
    const cost = unmortgageCost(index);
    if (player.money < cost + 320) continue;
    if (completesSet(state, player.id, index) || player.money > cost + 700) return index;
  }
  return null;
}

function pickSell(state: GameState): number | null {
  let choice: number | null = null;
  let best = -1;
  state.deeds.forEach((deed, index) => {
    if (!deed || sellBlock(state, index)) return;
    const space = SPACES[index];
    if (!space || space.kind !== "country") return;
    const value = GROUP_META[space.group].house * deed.houses;
    if (value > best) {
      best = value;
      choice = index;
    }
  });
  return choice;
}

function pickMortgage(state: GameState, player: Player): number | null {
  let choice: number | null = null;
  let best = Number.POSITIVE_INFINITY;
  for (const index of ownedIndexes(state, player.id)) {
    if (mortgageBlock(state, index)) continue;
    const price = spacePrice(index);
    const penalty = completesSet(state, player.id, index) ? 10_000 : 0;
    const score = price + penalty;
    if (score < best) {
      best = score;
      choice = index;
    }
  }
  return choice;
}

function tradeScore(state: GameState, forId: string, indexes: number[], moneyIn: number): number {
  let score = moneyIn;
  for (const index of indexes) {
    const price = spacePrice(index);
    const deed = state.deeds[index];
    score += deed?.mortgaged ? price * 0.45 : price;
    if (completesSet({ ...state, deeds: state.deeds.map((deedItem, deedIndex) => {
      if (deedIndex !== index || !deedItem) return deedItem;
      return { ...deedItem, ownerId: forId };
    }) }, forId, index)) {
      score += price * 0.7;
    }
  }
  return score;
}

function acceptTrade(state: GameState, bot: Player): boolean {
  const offer = state.trade;
  if (!offer || offer.toId !== bot.id) return false;
  if (bot.money < offer.takeMoney) return false;
  const incoming = tradeScore(state, bot.id, offer.give, offer.giveMoney);
  const outgoing = tradeScore(state, offer.fromId, offer.take, offer.takeMoney);
  return incoming > outgoing + 30 && bot.money - offer.takeMoney >= 80;
}

export function botAction(state: GameState): Action | null {
  const player = actor(state);
  if (!player || !player.isBot || player.bankrupt) return null;
  if (state.phase === "card") return { type: "ack-card" };
  if (state.phase === "turn") {
    const build = pickBuild(state, player);
    if (build != null) return { type: "build", index: build };
    const redeem = pickUnmortgage(state, player);
    if (redeem != null) return { type: "unmortgage", index: redeem };
    return { type: "roll" };
  }
  if (state.phase === "jail") {
    if (player.jailCards.chest > 0) return { type: "jail-card", deck: "chest" };
    if (player.jailCards.chance > 0) return { type: "jail-card", deck: "chance" };
    if (player.jailTurns >= 2 || player.money > 450) return { type: "jail-pay" };
    return { type: "jail-roll" };
  }
  if (state.phase === "buy" && state.buyIndex != null) {
    return wantsToBuy(state, player, state.buyIndex) ? { type: "buy" } : { type: "decline" };
  }
  if (state.phase === "auction" && state.auction && state.auction.turnId === player.id) {
    const ceiling = maxBid(state, player, state.auction.index);
    const step = Math.max(10, Math.floor(spacePrice(state.auction.index) * 0.12));
    const amount =
      state.auction.bid === 0
        ? Math.min(step, ceiling)
        : Math.min(state.auction.bid + step, ceiling);
    if (ceiling > state.auction.bid && amount > state.auction.bid) return { type: "bid", amount };
    return { type: "pass" };
  }
  if (state.phase === "trade") return acceptTrade(state, player) ? { type: "trade-accept" } : { type: "trade-reject" };
  if (state.phase === "debt" && state.obligations[0]?.fromId === player.id) {
    const due = state.obligations[0];
    if (player.money >= due.amount) return { type: "pay" };
    const sell = pickSell(state);
    if (sell != null) return { type: "sell", index: sell };
    const deed = pickMortgage(state, player);
    if (deed != null) return { type: "mortgage", index: deed };
    return { type: "bankrupt" };
  }
  return null;
}
