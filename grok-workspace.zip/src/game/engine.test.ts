import assert from "node:assert/strict";
import { beforeEach, describe, it } from "node:test";
import { BOARD_SIZE, SPACES, tilePlacement } from "./board.ts";
import {
  clearDiceQueue,
  createGame,
  queueDice,
  random,
  reduce,
  rentAmount,
  type Action,
} from "./engine.ts";
import type { GameState, SetupPlayer } from "./types.ts";

const styles = [
  { color: "#c44536", token: "plane" },
  { color: "#2c6eaf", token: "ship" },
  { color: "#1f8a4c", token: "car" },
] as const;

function humans(count = 3): SetupPlayer[] {
  return Array.from({ length: count }, (_, index) => ({
    name: `P${index + 1}`,
    human: true,
    color: styles[index]!.color,
    token: styles[index]!.token,
  }));
}

function flush(state: GameState): GameState {
  let guard = 0;
  let next = state;
  while ((next.phase === "rolling" || next.phase === "animating") && guard < 80) {
    const action: Action = next.phase === "rolling" ? { type: "begin-move" } : { type: "step" };
    next = reduce(next, action);
    guard += 1;
  }
  return next;
}

beforeEach(() => {
  random.next = () => 0;
  clearDiceQueue();
});

describe("papan", () => {
  it("punya 35 petak dan menutup seluruh pinggir", () => {
    assert.equal(SPACES.length, BOARD_SIZE);
    assert.equal(new Set(SPACES.map((space) => space.index)).size, 35);
    const countries = SPACES.filter((space) => space.kind === "country");
    const companies = SPACES.filter((space) => space.kind === "company");
    assert.equal(countries.length, 20);
    assert.equal(companies.length, 5);
    assert.equal(SPACES.filter((space) => space.kind === "chest").length, 3);
    assert.equal(SPACES.filter((space) => space.kind === "chance").length, 3);
    const cells: string[] = [];
    for (let index = 0; index < 35; index++) {
      const place = tilePlacement(index);
      for (let row = 0; row < place.span; row++) cells.push(`${place.col},${place.row + row}`);
    }
    assert.equal(new Set(cells).size, 36);
    assert.equal(cells.length, 36);
  });
});

describe("aturan", () => {
  it("membeli tanah dan menarik sewa", () => {
    let game = createGame(humans());
    assert.equal(game.current, 0);
    assert.equal(game.players[0]!.money, 1500);
    queueDice([[2, 3]]);
    game = flush(reduce(game, { type: "roll" }));
    assert.equal(game.players[0]!.pos, 5);
    assert.equal(game.phase, "buy");
    game = reduce(game, { type: "buy" });
    assert.equal(game.players[0]!.money, 1400);
    assert.equal(game.deeds[5]?.ownerId, "p1");
    assert.equal(game.current, 1);

    game = reduce(game, { type: "debug-turn", player: 1 });
    game = reduce(game, { type: "debug-pos", pos: 5 });
    game = reduce(game, { type: "debug-land" });
    assert.equal(game.players[1]!.money, 1500 - 6);
    assert.equal(game.players[0]!.money, 1406);
  });

  it("menggandakan sewa monopoli dan menolak bangunan timpang", () => {
    let game = createGame(humans());
    for (const index of [5, 7, 8]) game = reduce(game, { type: "debug-own", index, player: 0 });
    game = reduce(game, { type: "debug-turn", player: 1 });
    game = reduce(game, { type: "debug-pos", pos: 5 });
    game = reduce(game, { type: "debug-land" });
    assert.equal(rentAmount(game, 5), 12);
    assert.equal(game.players[1]!.money, 1500 - 12);

    game = reduce(game, { type: "debug-turn", player: 0 });
    game = reduce(game, { type: "build", index: 5 });
    assert.equal(game.deeds[5]?.houses, 1);
    const blocked = reduce(game, { type: "build", index: 5 });
    assert.equal(blocked.deeds[5]?.houses, 1);
    assert.match(blocked.notice ?? "", /merata/);
    game = reduce(game, { type: "build", index: 7 });
    assert.equal(game.deeds[7]?.houses, 1);
    assert.equal(game.players[0]!.money, 1500 + 12 - 100);
  });

  it("memberi gaji saat melewati Mulai dan tidak saat masuk penjara", () => {
    let game = createGame(humans());
    game = reduce(game, { type: "debug-pos", pos: 33 });
    queueDice([[1, 2]]);
    game = flush(reduce(game, { type: "roll" }));
    assert.equal(game.players[0]!.pos, 1);
    assert.equal(game.players[0]!.money, 1700);
    assert.equal(game.phase, "buy");

    game = createGame(humans());
    game = reduce(game, { type: "debug-pos", pos: 24 });
    queueDice([[1, 2]]);
    game = flush(reduce(game, { type: "roll" }));
    assert.equal(game.players[0]!.inJail, true);
    assert.equal(game.players[0]!.pos, 9);
    assert.equal(game.players[0]!.money, 1500);
    assert.notEqual(game.current, 0);
  });

  it("memenjarakan pemain setelah tiga kali kembar", () => {
    let game = createGame(humans());
    game = reduce(game, { type: "debug-own", index: 11, player: 0 });
    game = reduce(game, { type: "debug-own", index: 13, player: 0 });
    game = reduce(game, { type: "debug-pos", pos: 9 });
    queueDice([
      [1, 1],
      [1, 1],
      [4, 4],
    ]);
    game = flush(reduce(game, { type: "roll" }));
    assert.equal(game.phase, "turn");
    assert.equal(game.doubles, 1);
    assert.equal(game.players[0]!.pos, 11);
    game = flush(reduce(game, { type: "roll" }));
    assert.equal(game.doubles, 2);
    assert.equal(game.players[0]!.pos, 13);
    game = flush(reduce(game, { type: "roll" }));
    assert.equal(game.players[0]!.inJail, true);
    assert.equal(game.players[0]!.pos, 9);
    assert.notEqual(game.current, 0);
  });

  it("melelang tanah yang ditolak", () => {
    let game = createGame(humans());
    queueDice([[1, 3]]);
    game = flush(reduce(game, { type: "roll" }));
    assert.equal(game.buyIndex, 4);
    game = reduce(game, { type: "decline" });
    assert.equal(game.phase, "auction");
    assert.equal(game.auction?.turnId, "p2");
    game = reduce(game, { type: "bid", amount: 40 });
    game = reduce(game, { type: "pass" });
    game = reduce(game, { type: "pass" });
    assert.equal(game.deeds[4]?.ownerId, "p2");
    assert.equal(game.players[1]!.money, 1460);
    assert.equal(game.phase, "turn");
    assert.equal(game.current, 1);
  });

  it("memindahkan aset saat bangkrut dan mengakhiri permainan", () => {
    let game = createGame(humans(2));
    game = reduce(game, { type: "debug-own", index: 34, player: 0 });
    game = reduce(game, { type: "debug-own", index: 1, player: 1 });
    game = reduce(game, { type: "debug-turn", player: 1 });
    game = reduce(game, { type: "debug-money", player: 1, amount: 10 });
    game = reduce(game, { type: "debug-pos", pos: 34 });
    game = reduce(game, { type: "debug-land" });
    assert.equal(game.phase, "debt");
    game = reduce(game, { type: "bankrupt" });
    assert.equal(game.phase, "gameover");
    assert.equal(game.winnerId, "p1");
    assert.equal(game.deeds[1]?.ownerId, "p1");
    assert.equal(game.players[0]!.money, 1510);
  });

  it("menaruh denda penjara ke Parkir Bebas", () => {
    let game = createGame(humans());
    game = reduce(game, { type: "debug-turn", player: 0 });
    game.players[0]!.inJail = true;
    game.phase = "jail";
    game = reduce(game, { type: "jail-pay" });
    assert.equal(game.pot, 50);
    assert.equal(game.players[0]!.money, 1450);
    assert.equal(game.players[0]!.inJail, false);
    game = reduce(game, { type: "debug-turn", player: 1 });
    game = reduce(game, { type: "debug-pos", pos: 18 });
    game = reduce(game, { type: "debug-land" });
    assert.equal(game.pot, 0);
    assert.equal(game.players[1]!.money, 1550);
  });
});
