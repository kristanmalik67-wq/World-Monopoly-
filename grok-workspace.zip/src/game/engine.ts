import {
  BOARD_SIZE,
  CARDS,
  CHANCE_IDS,
  CHEST_IDS,
  COMPANY_RENT,
  GO_SALARY,
  GROUP_META,
  JAIL_FEE,
  JAIL_INDEX,
  SPACES,
  START_MONEY,
  TRANSPORT_INDEXES,
  UTILITY_INDEXES,
  groupIndexes,
  mortgageValue,
  shuffle,
  spacePrice,
  unmortgageCost,
} from "./board.ts";
import { money } from "./money.ts";
import type {
  Auction,
  DeckId,
  GameState,
  GroupId,
  Obligation,
  Player,
  Resume,
  SetupPlayer,
  TradeOffer,
} from "./types.ts";

export const random = {
  next: () => Math.random(),
};

const diceQueue: Array<[number, number]> = [];

export function queueDice(rolls: Array<[number, number]>) {
  diceQueue.push(...rolls);
}

export function clearDiceQueue() {
  diceQueue.length = 0;
}

function rollPair(): [number, number] {
  const queued = diceQueue.shift();
  if (queued) return queued;
  return [1 + Math.floor(random.next() * 6), 1 + Math.floor(random.next() * 6)];
}

export type Action =
  | { type: "roll" }
  | { type: "begin-move" }
  | { type: "step" }
  | { type: "buy" }
  | { type: "decline" }
  | { type: "bid"; amount: number }
  | { type: "pass" }
  | { type: "ack-card" }
  | { type: "jail-pay" }
  | { type: "jail-card"; deck: DeckId }
  | { type: "jail-roll" }
  | { type: "build"; index: number }
  | { type: "sell"; index: number }
  | { type: "mortgage"; index: number }
  | { type: "unmortgage"; index: number }
  | { type: "trade-propose"; offer: TradeOffer }
  | { type: "trade-accept" }
  | { type: "trade-reject" }
  | { type: "pay" }
  | { type: "bankrupt" }
  | { type: "surrender" }
  | { type: "debug-pos"; pos: number }
  | { type: "debug-own"; index: number; player: number }
  | { type: "debug-money"; player: number; amount: number }
  | { type: "debug-land" }
  | { type: "debug-turn"; player: number };

function cur(state: GameState): Player {
  return state.players[state.current]!;
}

function playerById(state: GameState, id: string): Player | undefined {
  return state.players.find((player) => player.id === id);
}

function pushLog(state: GameState, text: string, tone: "info" | "good" | "bad" = "info") {
  state.logId += 1;
  state.log.unshift({ id: state.logId, text, tone });
  if (state.log.length > 40) state.log.length = 40;
}

export function alivePlayers(state: GameState): Player[] {
  return state.players.filter((player) => !player.bankrupt);
}

function checkWinner(state: GameState): boolean {
  const alive = alivePlayers(state);
  if (alive.length > 1) return false;
  state.phase = "gameover";
  state.winnerId = alive[0]?.id ?? null;
  state.obligations = [];
  state.auction = null;
  state.trade = null;
  state.card = null;
  state.anim = null;
  if (alive[0]) pushLog(state, `${alive[0].name} menguasai papan dan menang.`, "good");
  return true;
}

function nextAliveIndex(state: GameState, from: number): number {
  for (let step = 1; step <= state.players.length; step++) {
    const index = (from + step) % state.players.length;
    if (!state.players[index]?.bankrupt) return index;
  }
  return from;
}

function nextPlayer(state: GameState): GameState {
  if (checkWinner(state)) return state;
  const index = nextAliveIndex(state, state.current);
  state.current = index;
  const player = cur(state);
  state.doubles = 0;
  state.dice = null;
  state.rentMul = 1;
  state.anim = null;
  state.forceJail = false;
  state.jailedThisTurn = false;
  state.buyIndex = null;
  state.resume = "finish";
  state.phase = player.inJail ? "jail" : "turn";
  return state;
}

function finishTurn(state: GameState): GameState {
  if (checkWinner(state)) return state;
  const player = cur(state);
  if (player.bankrupt || state.jailedThisTurn) {
    state.jailedThisTurn = false;
    state.doubles = 0;
    return nextPlayer(state);
  }
  if (state.doubles > 0 && !player.inJail) {
    state.phase = "turn";
    state.rentMul = 1;
    state.buyIndex = null;
    pushLog(state, "Dadu kembar. Lempar sekali lagi.", "good");
    return state;
  }
  return nextPlayer(state);
}

function afterQueue(state: GameState): GameState {
  if (checkWinner(state)) return state;
  const resume: Resume = state.resume;
  state.resume = "finish";
  const player = cur(state);
  if (resume === "move") {
    if (player.bankrupt || !state.anim) return player.bankrupt ? nextPlayer(state) : finishTurn(state);
    state.phase = "rolling";
    return state;
  }
  if (resume === "turn") {
    if (player.bankrupt) return nextPlayer(state);
    state.phase = player.inJail ? "jail" : "turn";
    return state;
  }
  if (player.bankrupt) return nextPlayer(state);
  return finishTurn(state);
}

function settle(state: GameState): GameState {
  while (state.obligations.length > 0) {
    const due = state.obligations[0]!;
    const payer = playerById(state, due.fromId);
    if (!payer || payer.bankrupt) {
      state.obligations.shift();
      continue;
    }
    if (payer.money < due.amount) {
      state.phase = "debt";
      return state;
    }
    payer.money -= due.amount;
    if (due.to.type === "player") {
      const creditor = playerById(state, due.to.id);
      if (creditor && !creditor.bankrupt) creditor.money += due.amount;
    } else if (due.to.type === "pot") {
      state.pot += due.amount;
    }
    pushLog(state, `${payer.name} membayar ${money(due.amount)} · ${due.reason}.`, "bad");
    state.obligations.shift();
  }
  return afterQueue(state);
}

function charge(state: GameState, obligation: Obligation): GameState {
  state.obligations.push(obligation);
  return settle(state);
}

function sendToJail(state: GameState): GameState {
  const player = cur(state);
  player.pos = JAIL_INDEX;
  player.inJail = true;
  player.jailTurns = 0;
  state.doubles = 0;
  state.anim = null;
  state.forceJail = false;
  state.jailedThisTurn = true;
  state.rentMul = 1;
  pushLog(state, `${player.name} masuk penjara.`, "bad");
  return finishTurn(state);
}

function nearestForward(from: number, targets: number[]): number {
  let best = targets[0] ?? from;
  let bestDist = BOARD_SIZE + 1;
  for (const target of targets) {
    const dist = (target - from + BOARD_SIZE) % BOARD_SIZE;
    if (dist > 0 && dist < bestDist) {
      bestDist = dist;
      best = target;
    }
  }
  return best;
}

function startWalk(
  state: GameState,
  steps: number,
  collectGo: boolean,
  backward: boolean,
  rentMul: number,
) {
  if (steps <= 0) {
    state.rentMul = rentMul;
    return land(state);
  }
  state.anim = { stepsLeft: steps, collectGo, backward, rentMul };
  state.phase = "animating";
  return state;
}

export function rentAmount(state: GameState, index: number): number {
  const space = SPACES[index];
  const deed = state.deeds[index];
  if (!space || !deed || !deed.ownerId || deed.mortgaged) return 0;
  if (space.kind === "country") {
    if (deed.houses > 0) return space.rents[deed.houses] ?? space.rents[0];
    const mates = groupIndexes(space.group);
    const ownedClear = mates.every((mate) => {
      const other = state.deeds[mate];
      return other?.ownerId === deed.ownerId && !other.mortgaged;
    });
    const improved = mates.some((mate) => (state.deeds[mate]?.houses ?? 0) > 0);
    if (ownedClear && !improved) return space.rents[0] * 2;
    return space.rents[0];
  }
  if (space.kind === "company") {
    const owned = SPACES.reduce((count, candidate, candidateIndex) => {
      if (candidate.kind !== "company") return count;
      const other = state.deeds[candidateIndex];
      if (other?.ownerId === deed.ownerId && !other.mortgaged) return count + 1;
      return count;
    }, 0);
    return COMPANY_RENT[owned] ?? 0;
  }
  return 0;
}

function land(state: GameState): GameState {
  const player = cur(state);
  const index = player.pos;
  const space = SPACES[index];
  if (!space) return finishTurn(state);
  if (space.kind === "start") {
    pushLog(state, `${player.name} berhenti di Mulai.`, "info");
    return finishTurn(state);
  }
  if (space.kind === "jail") {
    pushLog(state, `${player.name} hanya mampir di penjara.`, "info");
    return finishTurn(state);
  }
  if (space.kind === "parking") {
    const jackpot = state.pot;
    player.money += jackpot;
    state.pot = 0;
    pushLog(
      state,
      jackpot > 0
        ? `${player.name} mengambil jackpot Parkir Bebas ${money(jackpot)}.`
        : `${player.name} istirahat di Parkir Bebas.`,
      jackpot > 0 ? "good" : "info",
    );
    return finishTurn(state);
  }
  if (space.kind === "goto-jail") {
    pushLog(state, `${player.name} harus masuk penjara.`, "bad");
    return sendToJail(state);
  }
  if (space.kind === "chest" || space.kind === "chance") return drawCard(state, space.kind);
  return resolveProperty(state, index);
}

function resolveProperty(state: GameState, index: number): GameState {
  const space = SPACES[index];
  const deed = state.deeds[index];
  const player = cur(state);
  if (!space || !deed || (space.kind !== "country" && space.kind !== "company")) {
    return finishTurn(state);
  }
  if (!deed.ownerId) {
    state.rentMul = 1;
    state.buyIndex = index;
    state.phase = "buy";
    pushLog(state, `${space.name} belum dimiliki. Harga ${money(space.price)}.`, "info");
    return state;
  }
  if (deed.ownerId === player.id) {
    state.rentMul = 1;
    pushLog(state, `${player.name} mampir di ${space.name} miliknya.`, "info");
    return finishTurn(state);
  }
  if (deed.mortgaged) {
    state.rentMul = 1;
    pushLog(state, `${space.name} sedang dihipotek. Tidak ada sewa.`, "info");
    return finishTurn(state);
  }
  const owner = playerById(state, deed.ownerId);
  if (!owner || owner.bankrupt) {
    deed.ownerId = null;
    deed.mortgaged = false;
    state.buyIndex = index;
    state.phase = "buy";
    return state;
  }
  const amount = rentAmount(state, index) * Math.max(1, state.rentMul);
  state.rentMul = 1;
  state.resume = "finish";
  pushLog(state, `${player.name} mendarat di ${space.name} milik ${owner.name}.`, "info");
  return charge(state, {
    fromId: player.id,
    to: { type: "player", id: owner.id },
    amount,
    reason: `sewa ${space.name}`,
  });
}

function drawFrom(state: GameState, deck: DeckId): string | null {
  const pile = deck === "chest" ? state.chest : state.chance;
  const discard = deck === "chest" ? state.chestDiscard : state.chanceDiscard;
  if (pile.length === 0) {
    const reshuffled = shuffle(discard, random.next);
    discard.length = 0;
    pile.push(...reshuffled);
  }
  return pile.shift() ?? null;
}

function drawCard(state: GameState, deck: DeckId): GameState {
  const id = drawFrom(state, deck);
  if (!id || !CARDS[id]) {
    pushLog(state, "Tumpukan kartu kosong.", "info");
    return finishTurn(state);
  }
  const card = CARDS[id];
  if (card.effect.type !== "jail-card") {
    const discard = deck === "chest" ? state.chestDiscard : state.chanceDiscard;
    discard.push(id);
  }
  state.card = { id, deck };
  state.phase = "card";
  const label = deck === "chest" ? "Dana Umum" : "Kesempatan";
  pushLog(state, `${cur(state).name} membuka ${label}: ${card.title}.`, "info");
  return state;
}

function applyCard(state: GameState): GameState {
  const shown = state.card;
  state.card = null;
  if (!shown) return finishTurn(state);
  const card = CARDS[shown.id];
  if (!card) return finishTurn(state);
  const player = cur(state);
  const effect = card.effect;
  if (effect.type === "bank") {
    if (effect.amount >= 0) {
      player.money += effect.amount;
      pushLog(state, `${player.name} menerima ${money(effect.amount)}.`, "good");
      return finishTurn(state);
    }
    state.resume = "finish";
    return charge(state, {
      fromId: player.id,
      to: { type: "bank" },
      amount: -effect.amount,
      reason: card.title,
    });
  }
  if (effect.type === "pot") {
    state.resume = "finish";
    return charge(state, {
      fromId: player.id,
      to: { type: "pot" },
      amount: effect.amount,
      reason: card.title,
    });
  }
  if (effect.type === "collect" || effect.type === "pay-each") {
    const others = alivePlayers(state).filter((other) => other.id !== player.id);
    state.resume = "finish";
    if (others.length === 0) return finishTurn(state);
    for (const other of others) {
      state.obligations.push(
        effect.type === "collect"
          ? {
              fromId: other.id,
              to: { type: "player", id: player.id },
              amount: effect.amount,
              reason: card.title,
            }
          : {
              fromId: player.id,
              to: { type: "player", id: other.id },
              amount: effect.amount,
              reason: card.title,
            },
      );
    }
    return settle(state);
  }
  if (effect.type === "start") {
    const steps = (BOARD_SIZE - player.pos) % BOARD_SIZE;
    return startWalk(state, steps === 0 ? BOARD_SIZE : steps, true, false, 1);
  }
  if (effect.type === "goto") {
    const steps = (effect.index - player.pos + BOARD_SIZE) % BOARD_SIZE;
    return startWalk(state, steps, true, false, 1);
  }
  if (effect.type === "nearest") {
    const targets = effect.which === "transport" ? TRANSPORT_INDEXES : UTILITY_INDEXES;
    const target = nearestForward(player.pos, targets);
    const steps = (target - player.pos + BOARD_SIZE) % BOARD_SIZE;
    return startWalk(state, steps, true, false, 2);
  }
  if (effect.type === "back") {
    return startWalk(state, effect.steps, false, true, 1);
  }
  if (effect.type === "jail") return sendToJail(state);
  if (effect.type === "jail-card") {
    player.jailCards[shown.deck] += 1;
    pushLog(state, `${player.name} menyimpan kartu bebas penjara.`, "good");
    return finishTurn(state);
  }
  if (effect.type === "repair") {
    let cost = 0;
    state.deeds.forEach((deed, index) => {
      if (!deed || deed.ownerId !== player.id) return;
      const space = SPACES[index];
      if (!space || space.kind !== "country") return;
      if (deed.houses >= 5) cost += effect.hotel;
      else cost += deed.houses * effect.house;
    });
    if (cost <= 0) {
      pushLog(state, "Tidak ada bangunan yang perlu diperbaiki.", "info");
      return finishTurn(state);
    }
    state.resume = "finish";
    return charge(state, {
      fromId: player.id,
      to: { type: "pot" },
      amount: cost,
      reason: card.title,
    });
  }
  return finishTurn(state);
}

export function manager(state: GameState): Player | null {
  if (state.phase === "debt" && state.obligations[0]) {
    return playerById(state, state.obligations[0].fromId) ?? null;
  }
  if (state.phase === "turn" || state.phase === "jail" || state.phase === "buy") return cur(state);
  return null;
}

function ownsGroup(state: GameState, playerId: string, group: GroupId): boolean {
  return groupIndexes(group).every((index) => state.deeds[index]?.ownerId === playerId);
}

export function buildBlock(state: GameState, index: number): string | null {
  const actor = manager(state);
  if (!actor) return "Tidak bisa membangun sekarang.";
  if (state.phase === "debt") return "Selesaikan utang dulu.";
  const space = SPACES[index];
  const deed = state.deeds[index];
  if (!space || space.kind !== "country" || !deed) return "Petak ini tidak bisa dibangun.";
  if (deed.ownerId !== actor.id) return "Bukan milikmu.";
  if (deed.mortgaged) return "Sedang dihipotek.";
  if (deed.houses >= 5) return "Sudah hotel.";
  const mates = groupIndexes(space.group);
  if (!ownsGroup(state, actor.id, space.group)) return "Kuasi seluruh kelompok dulu.";
  if (mates.some((mate) => state.deeds[mate]?.mortgaged)) return "Masih ada tanah yang dihipotek.";
  const min = Math.min(...mates.map((mate) => state.deeds[mate]?.houses ?? 0));
  if (deed.houses > min) return "Bangun merata, mulai dari yang paling sedikit.";
  if (actor.money < GROUP_META[space.group].house) return "Uang tidak cukup.";
  return null;
}

export function sellBlock(state: GameState, index: number): string | null {
  const actor = manager(state);
  if (!actor) return "Tidak bisa menjual sekarang.";
  const space = SPACES[index];
  const deed = state.deeds[index];
  if (!space || space.kind !== "country" || !deed) return "Tidak ada bangunan.";
  if (deed.ownerId !== actor.id) return "Bukan milikmu.";
  if (deed.houses <= 0) return "Tidak ada bangunan.";
  const mates = groupIndexes(space.group);
  const max = Math.max(...mates.map((mate) => state.deeds[mate]?.houses ?? 0));
  if (deed.houses < max) return "Jual dari bangunan yang paling banyak dulu.";
  return null;
}

export function mortgageBlock(state: GameState, index: number): string | null {
  const actor = manager(state);
  if (!actor) return "Tidak bisa menghipotek sekarang.";
  const space = SPACES[index];
  const deed = state.deeds[index];
  if (!space || (space.kind !== "country" && space.kind !== "company") || !deed) {
    return "Petak ini tidak bisa dihipotek.";
  }
  if (deed.ownerId !== actor.id) return "Bukan milikmu.";
  if (deed.mortgaged) return "Sudah dihipotek.";
  if (deed.houses > 0) return "Jual bangunannya dulu.";
  if (space.kind === "country") {
    const busy = groupIndexes(space.group).some((mate) => (state.deeds[mate]?.houses ?? 0) > 0);
    if (busy) return "Jual semua bangunan di kelompok ini dulu.";
  }
  return null;
}

export function raiseableCash(state: GameState, playerId: string): number {
  const player = playerById(state, playerId);
  if (!player) return 0;
  let total = player.money;
  const houseRefund = new Map<GroupId, number>();
  state.deeds.forEach((deed, index) => {
    if (!deed || deed.ownerId !== playerId) return;
    const space = SPACES[index];
    if (!space) return;
    if (space.kind === "country" && deed.houses > 0) {
      total += Math.floor(GROUP_META[space.group].house / 2) * deed.houses;
      houseRefund.set(space.group, (houseRefund.get(space.group) ?? 0) + deed.houses);
    }
  });
  state.deeds.forEach((deed, index) => {
    if (!deed || deed.ownerId !== playerId || deed.mortgaged) return;
    const space = SPACES[index];
    if (!space || (space.kind !== "country" && space.kind !== "company")) return;
    if (space.kind === "country") {
      const blocked = groupIndexes(space.group).some((mate) => (state.deeds[mate]?.houses ?? 0) > 0);
      if (blocked) {
        /* buildings can be sold first, then the deed can be mortgaged */
      }
    }
    total += mortgageValue(index);
  });
  return total;
}

function deny(state: GameState, message: string): GameState {
  state.notice = message;
  return state;
}

function followingBidder(state: GameState, auction: Auction, fromId: string): string | "end" {
  const ids = alivePlayers(state).map((player) => player.id);
  const start = ids.indexOf(fromId);
  if (start < 0) return "end";
  for (let step = 1; step <= ids.length; step++) {
    const id = ids[(start + step) % ids.length]!;
    if (id === fromId) break;
    if (auction.passed.includes(id)) continue;
    if (auction.leaderId && id === auction.leaderId) continue;
    return id;
  }
  return "end";
}

function awardAuction(state: GameState): GameState {
  const auction = state.auction;
  state.auction = null;
  if (!auction) return finishTurn(state);
  const space = SPACES[auction.index];
  if (auction.leaderId && auction.bid > 0 && space) {
    const winner = playerById(state, auction.leaderId);
    const deed = state.deeds[auction.index];
    if (winner && deed) {
      winner.money -= auction.bid;
      deed.ownerId = winner.id;
      deed.mortgaged = false;
      deed.houses = 0;
      pushLog(
        state,
        `${winner.name} memenangkan lelang ${space.name} seharga ${money(auction.bid)}.`,
        "good",
      );
    }
  } else if (space) {
    pushLog(state, `Tidak ada yang menawar ${space.name}.`, "info");
  }
  return finishTurn(state);
}

function releaseDeeds(state: GameState, playerId: string, nextOwner: string | null) {
  state.deeds.forEach((deed) => {
    if (!deed || deed.ownerId !== playerId) return;
    deed.ownerId = nextOwner;
    if (!nextOwner) {
      deed.mortgaged = false;
      deed.houses = 0;
    }
  });
}

function bankruptPlayer(state: GameState, playerId: string, to: Obligation["to"]): GameState {
  const player = playerById(state, playerId);
  if (!player || player.bankrupt) return state;
  state.deeds.forEach((deed, index) => {
    if (!deed || deed.ownerId !== playerId || deed.houses <= 0) return;
    const space = SPACES[index];
    if (!space || space.kind !== "country") return;
    player.money += Math.floor(GROUP_META[space.group].house / 2) * deed.houses;
    deed.houses = 0;
  });
  const cash = player.money;
  player.money = 0;
  if (to.type === "player") {
    const creditor = playerById(state, to.id);
    if (creditor && !creditor.bankrupt) {
      creditor.money += cash;
      releaseDeeds(state, playerId, creditor.id);
    } else {
      releaseDeeds(state, playerId, null);
    }
  } else {
    if (to.type === "pot") state.pot += cash;
    releaseDeeds(state, playerId, null);
  }
  if (player.jailCards.chest > 0) {
    state.chestDiscard.push("dg-bebas");
    player.jailCards.chest = 0;
  }
  if (player.jailCards.chance > 0) {
    state.chanceDiscard.push("ks-bebas");
    player.jailCards.chance = 0;
  }
  player.bankrupt = true;
  player.inJail = false;
  state.obligations = state.obligations.filter((item) => item.fromId !== playerId);
  pushLog(state, `${player.name} bangkrut dan keluar dari permainan.`, "bad");
  return state;
}

function tradeOk(state: GameState, offer: TradeOffer): string | null {
  const from = playerById(state, offer.fromId);
  const to = playerById(state, offer.toId);
  if (!from || !to || from.bankrupt || to.bankrupt) return "Pemain tidak tersedia.";
  if (from.id === to.id) return "Pilih pemain lain.";
  if (offer.giveMoney < 0 || offer.takeMoney < 0) return "Nominal tidak valid.";
  if (offer.giveMoney > 0 && offer.takeMoney > 0) return "Uang hanya satu arah.";
  if (from.money < offer.giveMoney || to.money < offer.takeMoney) return "Uang tidak cukup.";
  const give = new Set(offer.give);
  const take = new Set(offer.take);
  if ([...give].some((index) => take.has(index))) return "Petak yang sama tidak bisa ditukar dua arah.";
  for (const index of offer.give) {
    const deed = state.deeds[index];
    if (!deed || deed.ownerId !== from.id) return "Kamu menawarkan petak yang bukan milikmu.";
    if (deed.houses > 0) return "Jual bangunan sebelum menukar tanah.";
  }
  for (const index of offer.take) {
    const deed = state.deeds[index];
    if (!deed || deed.ownerId !== to.id) return "Kamu meminta petak yang bukan miliknya.";
    if (deed.houses > 0) return "Lawan masih punya bangunan di tanah itu.";
  }
  if (offer.give.length + offer.take.length === 0 && offer.giveMoney + offer.takeMoney === 0) {
    return "Tawaran masih kosong.";
  }
  return null;
}

function applyTrade(state: GameState): GameState {
  const offer = state.trade;
  if (!offer) return state;
  const problem = tradeOk(state, offer);
  if (problem) return deny(state, problem);
  const from = playerById(state, offer.fromId)!;
  const to = playerById(state, offer.toId)!;
  from.money -= offer.giveMoney;
  to.money += offer.giveMoney;
  to.money -= offer.takeMoney;
  from.money += offer.takeMoney;
  for (const index of offer.give) {
    const deed = state.deeds[index];
    if (deed) deed.ownerId = to.id;
  }
  for (const index of offer.take) {
    const deed = state.deeds[index];
    if (deed) deed.ownerId = from.id;
  }
  pushLog(state, `${from.name} dan ${to.name} sepakat bertukar.`, "good");
  state.trade = null;
  state.phase = state.returnPhase;
  return state;
}

export function createGame(setups: SetupPlayer[]): GameState {
  const players: Player[] = setups.slice(0, 6).map((setup, index) => ({
    id: `p${index + 1}`,
    name: setup.name.trim() || `Pemain ${index + 1}`,
    color: setup.color,
    token: setup.token,
    isBot: !setup.human,
    money: START_MONEY,
    pos: 0,
    inJail: false,
    jailTurns: 0,
    jailCards: { chest: 0, chance: 0 },
    bankrupt: false,
  }));
  const starter = Math.floor(random.next() * players.length);
  const state: GameState = {
    saveVersion: 1,
    phase: "turn",
    players,
    current: starter,
    deeds: SPACES.map((space) =>
      space.kind === "country" || space.kind === "company"
        ? { ownerId: null, houses: 0, mortgaged: false }
        : null,
    ),
    pot: 0,
    chest: shuffle(CHEST_IDS, random.next),
    chestDiscard: [],
    chance: shuffle(CHANCE_IDS, random.next),
    chanceDiscard: [],
    doubles: 0,
    dice: null,
    anim: null,
    rentMul: 1,
    card: null,
    obligations: [],
    auction: null,
    trade: null,
    returnPhase: "turn",
    resume: "finish",
    forceJail: false,
    jailedThisTurn: false,
    buyIndex: null,
    log: [],
    logId: 0,
    notice: null,
    winnerId: null,
  };
  pushLog(
    state,
    `${players[starter]?.name ?? "Pemain"} dapat giliran pertama. Masing-masing membawa ${money(START_MONEY)}.`,
    "good",
  );
  return state;
}

function apply(state: GameState, action: Action): boolean {
  state.notice = null;
  switch (action.type) {
    case "roll": {
      if (state.phase !== "turn") return false;
      const player = cur(state);
      const [d1, d2] = rollPair();
      state.dice = [d1, d2];
      if (d1 === d2) state.doubles += 1;
      else state.doubles = 0;
      pushLog(state, `${player.name} melempar ${d1} dan ${d2}.`, "info");
      if (state.doubles >= 3) {
        state.forceJail = true;
        state.phase = "rolling";
        pushLog(state, "Tiga kali kembar berturut-turut. Masuk penjara.", "bad");
        return true;
      }
      state.anim = { stepsLeft: d1 + d2, collectGo: true, backward: false, rentMul: 1 };
      state.phase = "rolling";
      return true;
    }
    case "begin-move": {
      if (state.phase !== "rolling") return false;
      if (state.forceJail) return sendToJail(state) === state || true;
      if (!state.anim) {
        state.phase = "turn";
        return true;
      }
      state.phase = "animating";
      return true;
    }
    case "step": {
      if (state.phase !== "animating" || !state.anim) return false;
      const player = cur(state);
      const anim = state.anim;
      if (anim.backward) player.pos = (player.pos + BOARD_SIZE - 1) % BOARD_SIZE;
      else {
        player.pos = (player.pos + 1) % BOARD_SIZE;
        if (player.pos === 0 && anim.collectGo) {
          player.money += GO_SALARY;
          pushLog(state, `${player.name} melewati Mulai dan menerima ${money(GO_SALARY)}.`, "good");
        }
      }
      anim.stepsLeft -= 1;
      if (anim.stepsLeft > 0) return true;
      const rentMul = anim.rentMul;
      state.anim = null;
      state.rentMul = rentMul;
      land(state);
      return true;
    }
    case "buy": {
      if (state.phase !== "buy" || state.buyIndex == null) return false;
      const index = state.buyIndex;
      const price = spacePrice(index);
      const player = cur(state);
      const deed = state.deeds[index];
      const space = SPACES[index];
      if (!deed || !space) return false;
      if (player.money < price) {
        deny(state, "Uang tidak cukup. Hipotek aset, atau tolak untuk lelang.");
        return true;
      }
      player.money -= price;
      deed.ownerId = player.id;
      state.buyIndex = null;
      pushLog(state, `${player.name} membeli ${space.name} seharga ${money(price)}.`, "good");
      finishTurn(state);
      return true;
    }
    case "decline": {
      if (state.phase !== "buy" || state.buyIndex == null) return false;
      const index = state.buyIndex;
      state.buyIndex = null;
      const alive = alivePlayers(state);
      const space = SPACES[index];
      if (alive.length <= 1) {
        pushLog(state, `${space?.name ?? "Petak"} tidak dibeli.`, "info");
        finishTurn(state);
        return true;
      }
      const start = nextAliveIndex(state, state.current);
      state.auction = {
        index,
        bid: 0,
        leaderId: null,
        passed: [],
        turnId: state.players[start]!.id,
      };
      state.phase = "auction";
      pushLog(state, `Lelang ${space?.name ?? "petak"} dimulai.`, "info");
      return true;
    }
    case "bid": {
      if (state.phase !== "auction" || !state.auction) return false;
      const auction = state.auction;
      const bidder = playerById(state, auction.turnId);
      if (!bidder) return false;
      const min = auction.bid === 0 ? 1 : auction.bid + 10;
      if (!Number.isFinite(action.amount) || action.amount < min) {
        deny(state, `Tawaran minimum ${money(min)}.`);
        return true;
      }
      if (bidder.money < action.amount) {
        deny(state, "Uang penawar tidak cukup.");
        return true;
      }
      auction.bid = Math.floor(action.amount);
      auction.leaderId = bidder.id;
      const next = followingBidder(state, auction, bidder.id);
      if (next === "end") {
        awardAuction(state);
        return true;
      }
      auction.turnId = next;
      pushLog(state, `${bidder.name} menawar ${money(auction.bid)}.`, "info");
      return true;
    }
    case "pass": {
      if (state.phase !== "auction" || !state.auction) return false;
      const auction = state.auction;
      const bidder = playerById(state, auction.turnId);
      if (bidder && !auction.passed.includes(bidder.id)) auction.passed.push(auction.turnId);
      const next = followingBidder(state, auction, auction.turnId);
      if (bidder) pushLog(state, `${bidder.name} melewatkan lelang.`, "info");
      if (next === "end") {
        awardAuction(state);
        return true;
      }
      auction.turnId = next;
      return true;
    }
    case "ack-card": {
      if (state.phase !== "card") return false;
      applyCard(state);
      return true;
    }
    case "jail-pay": {
      if (state.phase !== "jail") return false;
      const player = cur(state);
      player.inJail = false;
      player.jailTurns = 0;
      state.resume = "turn";
      pushLog(state, `${player.name} membayar untuk keluar penjara.`, "info");
      charge(state, {
        fromId: player.id,
        to: { type: "pot" },
        amount: JAIL_FEE,
        reason: "keluar penjara",
      });
      return true;
    }
    case "jail-card": {
      if (state.phase !== "jail") return false;
      const player = cur(state);
      if (player.jailCards[action.deck] <= 0) {
        deny(state, "Kamu tidak punya kartu itu.");
        return true;
      }
      player.jailCards[action.deck] -= 1;
      player.inJail = false;
      player.jailTurns = 0;
      const discard = action.deck === "chest" ? state.chestDiscard : state.chanceDiscard;
      discard.push(action.deck === "chest" ? "dg-bebas" : "ks-bebas");
      state.phase = "turn";
      pushLog(state, `${player.name} memakai kartu bebas penjara.`, "good");
      return true;
    }
    case "jail-roll": {
      if (state.phase !== "jail") return false;
      const player = cur(state);
      const [d1, d2] = rollPair();
      state.dice = [d1, d2];
      state.doubles = 0;
      pushLog(state, `${player.name} melempar ${d1} dan ${d2} di penjara.`, "info");
      if (d1 === d2) {
        player.inJail = false;
        player.jailTurns = 0;
        state.anim = { stepsLeft: d1 + d2, collectGo: true, backward: false, rentMul: 1 };
        state.phase = "rolling";
        pushLog(state, "Kembar! Keluar dari penjara.", "good");
        return true;
      }
      player.jailTurns += 1;
      if (player.jailTurns >= 3) {
        player.inJail = false;
        player.jailTurns = 0;
        state.anim = { stepsLeft: d1 + d2, collectGo: true, backward: false, rentMul: 1 };
        state.resume = "move";
        pushLog(state, "Tiga giliran gagal. Bayar denda lalu jalan.", "bad");
        charge(state, {
          fromId: player.id,
          to: { type: "pot" },
          amount: JAIL_FEE,
          reason: "keluar penjara",
        });
        return true;
      }
      pushLog(state, "Bukan kembar. Masih di dalam penjara.", "info");
      nextPlayer(state);
      return true;
    }
    case "build": {
      const problem = buildBlock(state, action.index);
      if (problem) {
        deny(state, problem);
        return true;
      }
      const actor = manager(state)!;
      const space = SPACES[action.index];
      const deed = state.deeds[action.index]!;
      if (!space || space.kind !== "country") return false;
      const cost = GROUP_META[space.group].house;
      actor.money -= cost;
      deed.houses += 1;
      const built = deed.houses >= 5 ? "hotel" : `rumah ke-${deed.houses}`;
      pushLog(state, `${actor.name} membangun ${built} di ${space.name}.`, "good");
      return true;
    }
    case "sell": {
      const problem = sellBlock(state, action.index);
      if (problem) {
        deny(state, problem);
        return true;
      }
      const actor = manager(state)!;
      const space = SPACES[action.index];
      const deed = state.deeds[action.index]!;
      if (!space || space.kind !== "country") return false;
      const refund = Math.floor(GROUP_META[space.group].house / 2);
      deed.houses -= 1;
      actor.money += refund;
      pushLog(state, `${actor.name} menjual bangunan di ${space.name} (+${money(refund)}).`, "info");
      return true;
    }
    case "mortgage": {
      const problem = mortgageBlock(state, action.index);
      if (problem) {
        deny(state, problem);
        return true;
      }
      const actor = manager(state)!;
      const deed = state.deeds[action.index]!;
      const space = SPACES[action.index];
      const value = mortgageValue(action.index);
      deed.mortgaged = true;
      actor.money += value;
      pushLog(state, `${actor.name} menghipotek ${space?.name ?? "petak"} (+${money(value)}).`, "info");
      return true;
    }
    case "unmortgage": {
      const actor = manager(state);
      const deed = state.deeds[action.index];
      const space = SPACES[action.index];
      if (!actor || !deed || deed.ownerId !== actor.id || !deed.mortgaged) {
        deny(state, "Tidak bisa menebus hipotek itu.");
        return true;
      }
      const cost = unmortgageCost(action.index);
      if (actor.money < cost) {
        deny(state, "Uang tidak cukup untuk menebus hipotek.");
        return true;
      }
      actor.money -= cost;
      deed.mortgaged = false;
      pushLog(state, `${actor.name} menebus ${space?.name ?? "petak"} seharga ${money(cost)}.`, "info");
      return true;
    }
    case "trade-propose": {
      if (state.phase !== "turn" && state.phase !== "jail") {
        deny(state, "Tawar-menawar hanya sebelum dadu dilempar.");
        return true;
      }
      const actor = cur(state);
      if (action.offer.fromId !== actor.id) return false;
      const problem = tradeOk(state, action.offer);
      if (problem) {
        deny(state, problem);
        return true;
      }
      state.returnPhase = state.phase;
      state.trade = {
        ...action.offer,
        give: [...action.offer.give],
        take: [...action.offer.take],
      };
      state.phase = "trade";
      const to = playerById(state, action.offer.toId);
      pushLog(state, `${actor.name} mengajak ${to?.name ?? "lawan"} bertukar.`, "info");
      return true;
    }
    case "trade-accept": {
      if (state.phase !== "trade") return false;
      applyTrade(state);
      return true;
    }
    case "trade-reject": {
      if (state.phase !== "trade" || !state.trade) return false;
      const to = playerById(state, state.trade.toId);
      pushLog(state, `${to?.name ?? "Lawan"} menolak tawaran.`, "info");
      state.trade = null;
      state.phase = state.returnPhase;
      return true;
    }
    case "pay": {
      if (state.phase !== "debt") return false;
      const due = state.obligations[0];
      if (due) {
        const payer = playerById(state, due.fromId);
        if (payer && payer.money < due.amount) {
          deny(state, "Uang masih kurang. Jual bangunan atau hipotek dulu.");
          return true;
        }
      }
      settle(state);
      return true;
    }
    case "bankrupt": {
      if (state.phase !== "debt" || !state.obligations[0]) return false;
      const due = state.obligations[0];
      bankruptPlayer(state, due.fromId, due.to);
      if (checkWinner(state)) return true;
      settle(state);
      return true;
    }
    case "surrender": {
      if (state.phase !== "turn" && state.phase !== "jail" && state.phase !== "buy" && state.phase !== "debt") {
        return false;
      }
      const player = cur(state);
      if (player.bankrupt) return false;
      const to: Obligation["to"] =
        state.phase === "debt" && state.obligations[0] ? state.obligations[0].to : { type: "bank" };
      bankruptPlayer(state, player.id, to);
      if (checkWinner(state)) return true;
      if (state.phase === "debt") {
        settle(state);
        return true;
      }
      nextPlayer(state);
      return true;
    }
    case "debug-pos": {
      cur(state).pos = ((action.pos % BOARD_SIZE) + BOARD_SIZE) % BOARD_SIZE;
      return true;
    }
    case "debug-own": {
      const deed = state.deeds[action.index];
      const owner = state.players[action.player];
      if (!deed || !owner) return false;
      deed.ownerId = owner.id;
      deed.mortgaged = false;
      return true;
    }
    case "debug-money": {
      const player = state.players[action.player];
      if (!player) return false;
      player.money = action.amount;
      return true;
    }
    case "debug-land": {
      land(state);
      return true;
    }
    case "debug-turn": {
      const player = state.players[action.player];
      if (!player || player.bankrupt) return false;
      state.current = action.player;
      state.doubles = 0;
      state.phase = player.inJail ? "jail" : "turn";
      state.buyIndex = null;
      state.anim = null;
      return true;
    }
    default:
      return false;
  }
}

export function reduce(prev: GameState, action: Action): GameState {
  const state = structuredClone(prev);
  const changed = apply(state, action);
  if (!changed) return prev;
  return state;
}

export function ownedIndexes(state: GameState, playerId: string): number[] {
  return state.deeds.flatMap((deed, index) => (deed?.ownerId === playerId ? [index] : []));
}

export function netWorth(state: GameState, playerId: string): number {
  const player = playerById(state, playerId);
  if (!player || player.bankrupt) return 0;
  let total = player.money;
  state.deeds.forEach((deed, index) => {
    if (!deed || deed.ownerId !== playerId) return;
    const space = SPACES[index];
    if (!space || (space.kind !== "country" && space.kind !== "company")) return;
    total += deed.mortgaged ? mortgageValue(index) : space.price;
    if (space.kind === "country" && deed.houses > 0) {
      total += deed.houses * GROUP_META[space.group].house;
    }
  });
  return total;
}
