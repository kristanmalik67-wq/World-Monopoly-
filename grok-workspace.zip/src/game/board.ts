import type { CardDef, CompanyId, CountryGroup, GroupId, Space, TokenId } from "./types.ts";

export const BOARD_SIZE = 35;
export const GO_SALARY = 200;
export const START_MONEY = 1500;
export const JAIL_FEE = 50;
export const JAIL_INDEX = 9;
export const PARKING_INDEX = 18;
export const GOTO_JAIL_INDEX = 27;

/** Sewa perusahaan menurut jumlah yang dimiliki (tidak termasuk yang dihipotek). */
export const COMPANY_RENT = [0, 25, 50, 100, 200, 400] as const;

export const GROUP_META: Record<
  GroupId,
  { label: string; color: string; house: number }
> = {
  cokelat: { label: "Cokelat", color: "#8d5a3b", house: 50 },
  "biru-muda": { label: "Biru Muda", color: "#3d92c4", house: 50 },
  pink: { label: "Merah Muda", color: "#d45d8c", house: 100 },
  oranye: { label: "Oranye", color: "#e07a2f", house: 100 },
  merah: { label: "Merah", color: "#c23b3b", house: 150 },
  kuning: { label: "Kuning", color: "#c8960e", house: 150 },
  hijau: { label: "Hijau", color: "#1f8a55", house: 200 },
  "biru-tua": { label: "Biru Tua", color: "#1e4e8c", house: 200 },
  perusahaan: { label: "Perusahaan", color: "#3e5563", house: 0 },
};

export const PLAYER_STYLES: { color: string; token: TokenId; label: string }[] = [
  { color: "#c44536", token: "plane", label: "Merah" },
  { color: "#2c6eaf", token: "ship", label: "Biru" },
  { color: "#1f8a4c", token: "car", label: "Hijau" },
  { color: "#b7791f", token: "luggage", label: "Emas" },
  { color: "#6d4aff", token: "globe", label: "Ungu" },
  { color: "#0e7c86", token: "camera", label: "Teal" },
];

export const NAME_PRESETS = ["Alya", "Bima", "Citra", "Dimas", "Eka", "Farah"];

const country = (
  index: number,
  name: string,
  short: string,
  group: CountryGroup,
  price: number,
  rents: [number, number, number, number, number, number],
): Space => ({ index, kind: "country", name, short, group, price, rents });

const company = (
  index: number,
  name: string,
  short: string,
  companyId: CompanyId,
  price: number,
): Space => ({
  index,
  kind: "company",
  name,
  short,
  company: companyId,
  price,
});

const special = (
  index: number,
  kind: "start" | "jail" | "parking" | "goto-jail" | "chest" | "chance",
  name: string,
  short: string,
): Space => ({ index, kind, name, short });

export const SPACES: Space[] = [
  special(0, "start", "Mulai", "Mulai"),
  country(1, "Vietnam", "Vietnam", "cokelat", 60, [2, 10, 30, 90, 160, 250]),
  special(2, "chest", "Dana Umum", "Dana Umum"),
  country(3, "Kamboja", "Kamboja", "cokelat", 80, [4, 20, 60, 180, 320, 450]),
  company(4, "Perusahaan Listrik", "Listrik", "listrik", 150),
  country(5, "Thailand", "Thailand", "biru-muda", 100, [6, 30, 90, 270, 400, 550]),
  special(6, "chance", "Kesempatan", "Kesempatan"),
  country(7, "Malaysia", "Malaysia", "biru-muda", 100, [6, 30, 90, 270, 400, 550]),
  country(8, "Singapura", "Singapura", "biru-muda", 120, [8, 40, 100, 300, 450, 600]),
  special(9, "jail", "Penjara", "Penjara"),
  country(10, "Indonesia", "Indonesia", "pink", 140, [10, 50, 150, 450, 625, 750]),
  country(11, "Filipina", "Filipina", "pink", 140, [10, 50, 150, 450, 625, 750]),
  country(12, "Jepang", "Jepang", "pink", 160, [12, 60, 180, 500, 700, 900]),
  company(13, "Pelabuhan", "Pelabuhan", "pelabuhan", 200),
  country(14, "Korea Selatan", "Korea", "oranye", 180, [14, 70, 200, 550, 750, 950]),
  special(15, "chest", "Dana Umum", "Dana Umum"),
  country(16, "Tiongkok", "Tiongkok", "oranye", 180, [14, 70, 200, 550, 750, 950]),
  country(17, "India", "India", "oranye", 200, [16, 80, 220, 600, 800, 1000]),
  special(18, "parking", "Parkir Bebas", "Parkir"),
  country(19, "Uni Emirat Arab", "UEA", "merah", 220, [18, 90, 250, 700, 875, 1050]),
  country(20, "Turki", "Turki", "merah", 220, [18, 90, 250, 700, 875, 1050]),
  special(21, "chance", "Kesempatan", "Kesempatan"),
  country(22, "Mesir", "Mesir", "merah", 240, [20, 100, 300, 750, 925, 1100]),
  company(23, "Stasiun", "Stasiun", "stasiun", 200),
  country(24, "Italia", "Italia", "kuning", 260, [22, 110, 330, 800, 975, 1150]),
  country(25, "Spanyol", "Spanyol", "kuning", 280, [24, 120, 360, 850, 1025, 1200]),
  company(26, "Perusahaan Air", "Air", "air", 150),
  special(27, "goto-jail", "Masuk Penjara", "Masuk"),
  country(28, "Prancis", "Prancis", "hijau", 300, [26, 130, 390, 900, 1100, 1275]),
  country(29, "Inggris", "Inggris", "hijau", 320, [28, 150, 450, 1000, 1200, 1400]),
  special(30, "chance", "Kesempatan", "Kesempatan"),
  company(31, "Perusahaan Internet", "Internet", "internet", 160),
  special(32, "chest", "Dana Umum", "Dana Umum"),
  country(33, "Amerika Serikat", "AS", "biru-tua", 350, [35, 175, 500, 1100, 1300, 1500]),
  country(34, "Swiss", "Swiss", "biru-tua", 400, [50, 200, 600, 1400, 1700, 2000]),
];

export function tilePlacement(index: number): {
  col: number;
  row: number;
  span: number;
  side: "bottom" | "left" | "top" | "right";
} {
  if (index <= 9) return { col: 10 - index, row: 10, span: 1, side: "bottom" };
  if (index <= 18) return { col: 1, row: 19 - index, span: 1, side: "left" };
  if (index <= 27) return { col: index - 17, row: 1, span: 1, side: "top" };
  const right: Record<number, { row: number; span: number }> = {
    28: { row: 2, span: 1 },
    29: { row: 3, span: 1 },
    30: { row: 4, span: 1 },
    31: { row: 5, span: 2 },
    32: { row: 7, span: 1 },
    33: { row: 8, span: 1 },
    34: { row: 9, span: 1 },
  };
  const found = right[index];
  if (!found) return { col: 10, row: 2, span: 1, side: "right" };
  return { col: 10, row: found.row, span: found.span, side: "right" };
}

export function groupIndexes(group: GroupId): number[] {
  return SPACES.flatMap((space) => {
    if (space.kind === "country" && space.group === group) return [space.index];
    if (space.kind === "company" && group === "perusahaan") return [space.index];
    return [];
  });
}

export function spacePrice(index: number): number {
  const space = SPACES[index];
  if (!space || (space.kind !== "country" && space.kind !== "company")) return 0;
  return space.price;
}

export function mortgageValue(index: number): number {
  return Math.floor(spacePrice(index) / 2);
}

export function unmortgageCost(index: number): number {
  return Math.round(mortgageValue(index) * 1.1);
}

export const TRANSPORT_INDEXES = SPACES.flatMap((space) =>
  space.kind === "company" && (space.company === "stasiun" || space.company === "pelabuhan")
    ? [space.index]
    : [],
);

export const UTILITY_INDEXES = SPACES.flatMap((space) =>
  space.kind === "company" &&
  (space.company === "listrik" || space.company === "air" || space.company === "internet")
    ? [space.index]
    : [],
);

export const CARDS: Record<string, CardDef> = {};

function addCard(card: CardDef) {
  CARDS[card.id] = card;
}

addCard({
  id: "dg-bank",
  deck: "chest",
  title: "Kesalahan bank",
  text: "Kasir salah hitung. Terima K200.",
  effect: { type: "bank", amount: 200 },
});
addCard({
  id: "dg-dokter",
  deck: "chest",
  title: "Biaya dokter",
  text: "Bayar K50. Uang masuk Parkir Bebas.",
  effect: { type: "pot", amount: 50 },
});
addCard({
  id: "dg-warisan",
  deck: "chest",
  title: "Warisan",
  text: "Kamu menerima warisan K100.",
  effect: { type: "bank", amount: 100 },
});
addCard({
  id: "dg-saham",
  deck: "chest",
  title: "Jual saham",
  text: "Penjualan saham menghasilkan K50.",
  effect: { type: "bank", amount: 50 },
});
addCard({
  id: "dg-pajak",
  deck: "chest",
  title: "Restitusi pajak",
  text: "Pengembalian pajak K20.",
  effect: { type: "bank", amount: 20 },
});
addCard({
  id: "dg-ultah",
  deck: "chest",
  title: "Ulang tahun",
  text: "Setiap pemain lain memberimu K10.",
  effect: { type: "collect", amount: 10 },
});
addCard({
  id: "dg-rs",
  deck: "chest",
  title: "Rumah sakit",
  text: "Bayar biaya rumah sakit K100 ke Parkir Bebas.",
  effect: { type: "pot", amount: 100 },
});
addCard({
  id: "dg-kontes",
  deck: "chest",
  title: "Juara kontes",
  text: "Hadiah kontes K100.",
  effect: { type: "bank", amount: 100 },
});
addCard({
  id: "dg-bunga",
  deck: "chest",
  title: "Bunga tabungan",
  text: "Bunga tabungan K25.",
  effect: { type: "bank", amount: 25 },
});
addCard({
  id: "dg-sekolah",
  deck: "chest",
  title: "Biaya sekolah",
  text: "Bayar K50 ke Parkir Bebas.",
  effect: { type: "pot", amount: 50 },
});
addCard({
  id: "dg-asuransi",
  deck: "chest",
  title: "Asuransi",
  text: "Klaim asuransi cair K100.",
  effect: { type: "bank", amount: 100 },
});
addCard({
  id: "dg-ketua",
  deck: "chest",
  title: "Terpilih ketua",
  text: "Bayar K50 kepada setiap pemain lain.",
  effect: { type: "pay-each", amount: 50 },
});
addCard({
  id: "dg-mulai",
  deck: "chest",
  title: "Maju ke Mulai",
  text: "Langsung ke Mulai dan ambil gaji.",
  effect: { type: "start" },
});
addCard({
  id: "dg-penjara",
  deck: "chest",
  title: "Masuk penjara",
  text: "Pergi ke penjara. Tidak melewati Mulai.",
  effect: { type: "jail" },
});
addCard({
  id: "dg-bebas",
  deck: "chest",
  title: "Bebas penjara",
  text: "Simpan kartu ini. Pakai untuk keluar penjara.",
  effect: { type: "jail-card" },
});
addCard({
  id: "dg-jalan",
  deck: "chest",
  title: "Perbaikan kota",
  text: "Bayar K40 per rumah dan K115 per hotel ke Parkir Bebas.",
  effect: { type: "repair", house: 40, hotel: 115 },
});

addCard({
  id: "ks-mulai",
  deck: "chance",
  title: "Maju ke Mulai",
  text: "Langsung ke Mulai dan ambil gaji.",
  effect: { type: "start" },
});
addCard({
  id: "ks-swiss",
  deck: "chance",
  title: "Maju ke Swiss",
  text: "Maju ke Swiss. Ambil gaji jika melewati Mulai.",
  effect: { type: "goto", index: 34 },
});
addCard({
  id: "ks-indonesia",
  deck: "chance",
  title: "Maju ke Indonesia",
  text: "Maju ke Indonesia. Ambil gaji jika melewati Mulai.",
  effect: { type: "goto", index: 10 },
});
addCard({
  id: "ks-transport",
  deck: "chance",
  title: "Transport terdekat",
  text: "Maju ke Stasiun atau Pelabuhan terdekat. Sewa digandakan jika milik orang lain.",
  effect: { type: "nearest", which: "transport" },
});
addCard({
  id: "ks-util",
  deck: "chance",
  title: "Utilitas terdekat",
  text: "Maju ke Listrik, Air, atau Internet terdekat. Sewa digandakan jika milik orang lain.",
  effect: { type: "nearest", which: "utility" },
});
addCard({
  id: "ks-dividen",
  deck: "chance",
  title: "Dividen",
  text: "Bank membagikan dividen K50.",
  effect: { type: "bank", amount: 50 },
});
addCard({
  id: "ks-mundur",
  deck: "chance",
  title: "Mundur tiga",
  text: "Mundur tiga langkah.",
  effect: { type: "back", steps: 3 },
});
addCard({
  id: "ks-penjara",
  deck: "chance",
  title: "Masuk penjara",
  text: "Langsung masuk penjara. Tidak melewati Mulai.",
  effect: { type: "jail" },
});
addCard({
  id: "ks-perbaikan",
  deck: "chance",
  title: "Perbaikan umum",
  text: "Bayar K25 per rumah dan K100 per hotel ke Parkir Bebas.",
  effect: { type: "repair", house: 25, hotel: 100 },
});
addCard({
  id: "ks-bebas",
  deck: "chance",
  title: "Bebas penjara",
  text: "Simpan kartu ini. Pakai untuk keluar penjara.",
  effect: { type: "jail-card" },
});
addCard({
  id: "ks-ngebut",
  deck: "chance",
  title: "Denda ngebut",
  text: "Bayar denda K15 ke Parkir Bebas.",
  effect: { type: "pot", amount: 15 },
});
addCard({
  id: "ks-singapura",
  deck: "chance",
  title: "Maju ke Singapura",
  text: "Maju ke Singapura. Ambil gaji jika melewati Mulai.",
  effect: { type: "goto", index: 8 },
});
addCard({
  id: "ks-prancis",
  deck: "chance",
  title: "Maju ke Prancis",
  text: "Maju ke Prancis. Ambil gaji jika melewati Mulai.",
  effect: { type: "goto", index: 28 },
});
addCard({
  id: "ks-dewan",
  deck: "chance",
  title: "Ketua dewan",
  text: "Setiap pemain lain membayar K50 kepadamu.",
  effect: { type: "collect", amount: 50 },
});
addCard({
  id: "ks-pinjaman",
  deck: "chance",
  title: "Pinjaman jatuh tempo",
  text: "Bayar K150 ke Parkir Bebas.",
  effect: { type: "pot", amount: 150 },
});
addCard({
  id: "ks-pelabuhan",
  deck: "chance",
  title: "Maju ke Pelabuhan",
  text: "Maju ke Pelabuhan. Ambil gaji jika melewati Mulai.",
  effect: { type: "goto", index: 13 },
});

export const CHEST_IDS = Object.values(CARDS)
  .filter((card) => card.deck === "chest")
  .map((card) => card.id);

export const CHANCE_IDS = Object.values(CARDS)
  .filter((card) => card.deck === "chance")
  .map((card) => card.id);

export function shuffle<T>(list: T[], rng: () => number): T[] {
  const next = [...list];
  for (let i = next.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const swap = next[i]!;
    next[i] = next[j]!;
    next[j] = swap;
  }
  return next;
}
