import { createFileRoute } from "@tanstack/react-router";
import { MonopoliApp } from "@/components/monopoli/MonopoliApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <MonopoliApp />;
}
