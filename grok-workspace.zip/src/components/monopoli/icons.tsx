import {
  Anchor,
  Camera,
  Car,
  CircleParking,
  Droplets,
  Flag,
  Globe,
  Lock,
  Luggage,
  Plane,
  ScrollText,
  Ship,
  Siren,
  Sparkles,
  TrainFront,
  Wifi,
  Zap,
} from "lucide-react";
import type { Space, TokenId } from "@/game/types";

const tokens: Record<TokenId, typeof Plane> = {
  plane: Plane,
  ship: Ship,
  car: Car,
  luggage: Luggage,
  globe: Globe,
  camera: Camera,
};

export function TokenGlyph({ id, size = 12 }: { id: TokenId; size?: number }) {
  const Icon = tokens[id];
  return <Icon size={size} strokeWidth={2.5} aria-hidden />;
}

export function SpaceGlyph({ space, size = 12 }: { space: Space; size?: number }) {
  const common = { size, strokeWidth: 2.2, "aria-hidden": true as const };
  if (space.kind === "start") return <Flag {...common} />;
  if (space.kind === "jail") return <Lock {...common} />;
  if (space.kind === "parking") return <CircleParking {...common} />;
  if (space.kind === "goto-jail") return <Siren {...common} />;
  if (space.kind === "chest") return <ScrollText {...common} />;
  if (space.kind === "chance") return <Sparkles {...common} />;
  if (space.kind === "company") {
    if (space.company === "listrik") return <Zap {...common} />;
    if (space.company === "air") return <Droplets {...common} />;
    if (space.company === "internet") return <Wifi {...common} />;
    if (space.company === "stasiun") return <TrainFront {...common} />;
    return <Anchor {...common} />;
  }
  return null;
}
