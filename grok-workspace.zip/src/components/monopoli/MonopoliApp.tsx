import { useEffect, useState } from "react";
import { BOARD_SIZE } from "@/game/board";
import { useGame } from "@/game/store";
import { Setup } from "./Setup";
import { Table } from "./Table";

export function MonopoliApp() {
  const game = useGame((store) => store.game);
  const reset = useGame((store) => store.reset);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const finish = () => setReady(true);
    const unsub = useGame.persist.onFinishHydration(finish);
    void useGame.persist.rehydrate();
    if (useGame.persist.hasHydrated()) finish();
    return unsub;
  }, []);

  useEffect(() => {
    if (!ready) return;
    const saved = useGame.getState().game;
    if (!saved) return;
    if (saved.saveVersion !== 1 || saved.deeds.length !== BOARD_SIZE || saved.players.length < 2) reset();
  }, [ready, reset]);

  if (!ready) {
    return (
      <main className="splash">
        <h1>Monopoli Dunia</h1>
      </main>
    );
  }
  if (!game) return <Setup />;
  return <Table />;
}
