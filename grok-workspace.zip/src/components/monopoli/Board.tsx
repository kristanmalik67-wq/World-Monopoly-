import { GROUP_META, SPACES, tilePlacement } from "@/game/board";
import { money } from "@/game/money";
import type { GameState } from "@/game/types";
import { SpaceGlyph, TokenGlyph } from "./icons";

const PIPS: Record<number, number[]> = {
  1: [4],
  2: [0, 8],
  3: [0, 4, 8],
  4: [0, 2, 6, 8],
  5: [0, 2, 4, 6, 8],
  6: [0, 2, 3, 5, 6, 8],
};

export function Die({ value, rolling }: { value: number | null; rolling: boolean }) {
  const on = new Set(value ? PIPS[value] : []);
  return (
    <span className="die" data-rolling={rolling ? "yes" : "no"} aria-hidden>
      {Array.from({ length: 9 }, (_, index) => (
        <i key={index} data-on={on.has(index) ? "yes" : "no"} />
      ))}
    </span>
  );
}

export function Board({
  game,
  selected,
  onSelect,
}: {
  game: GameState;
  selected: number | null;
  onSelect: (index: number) => void;
}) {
  const current = game.players[game.current];
  const rolling = game.phase === "rolling";
  return (
    <div className="board" data-testid="board">
      <div className="center">
        <p className="hint">Dari Mulai, jalan ke kiri</p>
        <h2 className="wordmark">
          Monopoli
          <span>Dunia</span>
        </h2>
        <div className="dice-row" aria-label={game.dice ? `Dadu ${game.dice[0]} dan ${game.dice[1]}` : "Dadu"}>
          <Die value={rolling ? null : (game.dice?.[0] ?? null)} rolling={rolling} />
          <Die value={rolling ? null : (game.dice?.[1] ?? null)} rolling={rolling} />
        </div>
        {current && game.phase !== "gameover" ? (
          <p className="turn-pill">{current.name}</p>
        ) : null}
        <p className="pot-pill">Parkir Bebas {money(game.pot)}</p>
      </div>
      {SPACES.map((space) => {
        const place = tilePlacement(space.index);
        const deed = game.deeds[space.index];
        const owner = deed?.ownerId ? game.players.find((player) => player.id === deed.ownerId) : undefined;
        const here = game.players.filter((player) => !player.bankrupt && player.pos === space.index);
        const band =
          space.kind === "country"
            ? GROUP_META[space.group].color
            : space.kind === "company"
              ? GROUP_META.perusahaan.color
              : undefined;
        const houses = deed?.houses ?? 0;
        return (
          <button
            key={space.index}
            type="button"
            className="tile"
            data-side={place.side}
            data-kind={space.kind}
            data-pos={space.index}
            data-owned={owner ? "yes" : "no"}
            data-selected={selected === space.index ? "yes" : "no"}
            style={{
              gridColumn: place.col,
              gridRow: place.span > 1 ? `${place.row} / span ${place.span}` : place.row,
              ["--band" as string]: band,
              ["--owner" as string]: owner?.color ?? "transparent",
            }}
            onClick={() => onSelect(space.index)}
            aria-label={space.name}
          >
            {band ? (
              <span className="band">
                {houses > 0 ? (
                  <span className="house-row">
                    {houses >= 5 ? <i className="hotel-pip" /> : Array.from({ length: houses }, (_, index) => (
                      <i key={index} className="house-pip" />
                    ))}
                  </span>
                ) : null}
              </span>
            ) : (
              <span className="tile-icon">
                <SpaceGlyph space={space} size={place.span > 1 ? 16 : 12} />
              </span>
            )}
            <span className="tile-body">
              <span className="tile-name">{space.short}</span>
              {deed && !deed.ownerId && (space.kind === "country" || space.kind === "company") ? (
                <span className="tile-price">{money(space.price)}</span>
              ) : null}
              {deed?.mortgaged ? <span className="mort">Hipotek</span> : null}
            </span>
            {here.length > 0 ? (
              <span className="token-row">
                {here.slice(0, 4).map((player) => (
                  <span
                    key={player.id}
                    className="pawn"
                    data-live={player.id === current?.id ? "yes" : "no"}
                    data-jailed={player.inJail ? "yes" : "no"}
                    style={{ ["--pawn" as string]: player.color }}
                    title={player.name}
                  >
                    <TokenGlyph id={player.token} size={9} />
                  </span>
                ))}
              </span>
            ) : null}
          </button>
        );
      })}
    </div>
  );
}
