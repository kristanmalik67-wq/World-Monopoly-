import { useEffect, useRef, useState, type ReactNode } from "react";
import { botAction } from "@/game/ai";
import { play, unlockAudio } from "@/game/audio";
import {
  CARDS,
  COMPANY_RENT,
  GROUP_META,
  JAIL_FEE,
  SPACES,
  mortgageValue,
  spacePrice,
  unmortgageCost,
} from "@/game/board";
import {
  buildBlock,
  manager,
  mortgageBlock,
  netWorth,
  ownedIndexes,
  rentAmount,
  sellBlock,
} from "@/game/engine";
import { money } from "@/game/money";
import { useGame } from "@/game/store";
import type { GameState, TradeOffer } from "@/game/types";
import { Board } from "./Board";
import { TokenGlyph } from "./icons";

function flushMotion(game: GameState, dispatch: (action: { type: "begin-move" } | { type: "step" }) => void) {
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (game.phase === "rolling") return window.setTimeout(() => dispatch({ type: "begin-move" }), reduced ? 40 : 520);
  if (game.phase === "animating") return window.setTimeout(() => dispatch({ type: "step" }), reduced ? 16 : 150);
  return undefined;
}

export function Table() {
  const game = useGame((store) => store.game);
  const dispatch = useGame((store) => store.dispatch);
  const reset = useGame((store) => store.reset);
  const [selected, setSelected] = useState<number | null>(0);
  const [rules, setRules] = useState(false);
  const [confirmNew, setConfirmNew] = useState(false);
  const [tradeOpen, setTradeOpen] = useState(false);
  const [give, setGive] = useState<number[]>([]);
  const [take, setTake] = useState<number[]>([]);
  const [giveMoney, setGiveMoney] = useState(0);
  const [takeMoney, setTakeMoney] = useState(0);
  const [toId, setToId] = useState("");
  const [bid, setBid] = useState("10");
  const [armOut, setArmOut] = useState(false);
  const lock = useRef("");

  useEffect(() => {
    if (!game) return;
    if (game.buyIndex != null) setSelected(game.buyIndex);
    else if (game.auction) setSelected(game.auction.index);
  }, [game]);

  useEffect(() => {
    setArmOut(false);
  }, [game?.current, game?.phase]);

  useEffect(() => {
    if (!game) return;
    const timer = flushMotion(game, dispatch);
    if (timer) return () => window.clearTimeout(timer);
    const action = botAction(game);
    if (!action) return;
    const signature = JSON.stringify({
      action,
      phase: game.phase,
      current: game.current,
      logId: game.logId,
      money: game.players.map((player) => player.money),
      houses: game.deeds.map((deed) => deed?.houses ?? -1),
      bid: game.auction?.bid ?? -1,
      turn: game.auction?.turnId ?? "",
      debt: game.obligations[0]?.amount ?? 0,
    });
    if (lock.current === signature) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const wait = game.phase === "card" ? 1100 : 640;
    const botTimer = window.setTimeout(() => {
      lock.current = signature;
      dispatch(action);
    }, reduced ? 40 : wait);
    return () => window.clearTimeout(botTimer);
  }, [game, dispatch]);

  useEffect(() => {
    const line = game?.log[0];
    if (!line) return;
    if (line.text.includes("melempar")) play("dice");
    else if (line.text.includes("masuk penjara")) play("jail");
    else if (line.text.includes("menang")) play("win");
    else if (line.text.includes("melewati Mulai") || line.text.includes("jackpot") || line.text.includes("membeli")) play("go");
    else if (line.text.includes("membayar")) play("coin");
  }, [game?.log[0]?.id]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (!game || rules || confirmNew || game.phase !== "turn") return;
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "BUTTON" || tag === "SELECT") return;
      if (event.code === "Space") {
        event.preventDefault();
        dispatch({ type: "roll" });
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [game, rules, confirmNew, dispatch]);

  if (!game) return null;
  const current = game.players[game.current]!;
  const actor = manager(game);
  const others = game.players.filter((player) => !player.bankrupt && player.id !== current.id);

  function toggle(list: number[], index: number, setList: (next: number[]) => void) {
    setList(list.includes(index) ? list.filter((item) => item !== index) : [...list, index]);
  }

  function propose() {
    const offer: TradeOffer = {
      fromId: current.id,
      toId: toId || others[0]?.id || "",
      giveMoney: Math.max(0, giveMoney),
      takeMoney: Math.max(0, takeMoney),
      give,
      take,
    };
    dispatch({ type: "trade-propose", offer });
    setTradeOpen(false);
  }

  return (
    <div className="shell" onPointerDown={unlockAudio}>
      <header className="topbar">
        <div>
          <p className="eyebrow">Papan internasional</p>
          <h1>Monopoli Dunia</h1>
        </div>
        <div className="top-actions">
          <button type="button" className="btn-light" onClick={() => setRules(true)}>
            Aturan
          </button>
          <button type="button" className="btn-light" onClick={() => setConfirmNew(true)}>
            Permainan baru
          </button>
        </div>
      </header>
      <div className="layout">
        <div className="board-wrap">
          <Board game={game} selected={selected} onSelect={setSelected} />
        </div>
        <aside className="side">
          <section className="panel">
            <p className="eyebrow">Pemain</p>
            <ul className="roster">
              {game.players.map((player, index) => (
                <li key={player.id} data-turn={index === game.current && game.phase !== "gameover" ? "yes" : "no"} data-out={player.bankrupt ? "yes" : "no"}>
                  <span className="pawn pawn-lg" data-jailed={player.inJail ? "yes" : "no"} style={{ ["--pawn" as string]: player.color }}>
                    <TokenGlyph id={player.token} size={15} />
                  </span>
                  <p>
                    <span className="who">{player.name}</span>
                    {player.isBot ? <span className="tag">Komputer</span> : null}
                    {player.inJail ? <span className="tag tag-bad">Penjara {player.jailTurns}/3</span> : null}
                    {player.bankrupt ? <span className="tag">Bangkrut</span> : null}
                  </p>
                  <span className="cash" title={`Kekayaan ${money(netWorth(game, player.id))}`}>
                    {player.bankrupt ? "—" : money(player.money)}
                  </span>
                </li>
              ))}
            </ul>
          </section>

          <section className="panel panel-play">
            {game.notice ? <p className="notice" role="status">{game.notice}</p> : null}
            <Dock
              game={game}
              bid={bid}
              setBid={setBid}
              onTrade={() => {
                setToId(others[0]?.id ?? "");
                setGive([]);
                setTake([]);
                setGiveMoney(0);
                setTakeMoney(0);
                setTradeOpen(true);
              }}
            />
            {tradeOpen && (game.phase === "turn" || game.phase === "jail") ? (
              <TradeBox
                game={game}
                currentId={current.id}
                toId={toId || others[0]?.id || ""}
                setToId={setToId}
                give={give}
                take={take}
                giveMoney={giveMoney}
                takeMoney={takeMoney}
                setGiveMoney={setGiveMoney}
                setTakeMoney={setTakeMoney}
                toggleGive={(index) => toggle(give, index, setGive)}
                toggleTake={(index) => toggle(take, index, setTake)}
                onCancel={() => setTradeOpen(false)}
                onSend={propose}
              />
            ) : null}
            {game.phase === "turn" || game.phase === "jail" || game.phase === "buy" ? (
              <button type="button" className="btn-quiet" onClick={() => (armOut ? dispatch({ type: "surrender" }) : setArmOut(true))}>
                {armOut ? "Yakin menyerah?" : "Menyerah"}
              </button>
            ) : null}
          </section>

          <Detail game={game} index={selected} actorId={actor?.id ?? null} />

          <section className="panel">
            <p className="eyebrow">Catatan</p>
            <ol className="log">
              {game.log.slice(0, 8).map((line) => (
                <li key={line.id} data-tone={line.tone}>{line.text}</li>
              ))}
            </ol>
          </section>
        </aside>
      </div>

      {game.phase === "card" && game.card ? <CardModal /> : null}
      {game.phase === "trade" && game.trade ? <TradeModal /> : null}
      {game.phase === "gameover" ? (
        <Modal>
          <p className="eyebrow">Selesai</p>
          <h2>{game.players.find((player) => player.id === game.winnerId)?.name ?? "Pemain"} menguasai papan.</h2>
          <p className="lede">Kekayaan {money(netWorth(game, game.winnerId ?? ""))}.</p>
          <button type="button" className="btn" onClick={reset}>Main lagi</button>
        </Modal>
      ) : null}
      {rules ? <Rules onClose={() => setRules(false)} /> : null}
      {confirmNew ? (
        <Modal>
          <h2>Mulai dari awal?</h2>
          <p className="lede">Permainan yang sedang berjalan akan dihapus di perangkat ini.</p>
          <div className="btn-row">
            <button type="button" className="btn-line" onClick={() => setConfirmNew(false)}>Batal</button>
            <button type="button" className="btn-danger" onClick={reset}>Hapus dan mulai lagi</button>
          </div>
        </Modal>
      ) : null}
    </div>
  );
}

function headline(game: GameState): string {
  const current = game.players[game.current];
  if (game.phase === "gameover") return "Permainan selesai";
  if (game.phase === "debt" && game.obligations[0]) {
    const who = game.players.find((player) => player.id === game.obligations[0]?.fromId);
    return `${who?.name ?? "Pemain"} kurang ${money(game.obligations[0].amount)}`;
  }
  if (game.phase === "auction" && game.auction) return `Lelang ${SPACES[game.auction.index]?.name ?? ""}`;
  if (game.phase === "buy" && game.buyIndex != null) return `${SPACES[game.buyIndex]?.name ?? "Tanah"} dijual`;
  if (game.phase === "jail") return `${current?.name ?? ""} di penjara`;
  if (game.phase === "card" && game.card) return CARDS[game.card.id]?.title ?? "Kartu";
  if (game.phase === "trade") return "Tawaran tukar";
  if (game.phase === "rolling" || game.phase === "animating") return `${current?.name ?? ""} berjalan`;
  return `Giliran ${current?.name ?? ""}`;
}

function Dock({
  game,
  bid,
  setBid,
  onTrade,
}: {
  game: GameState;
  bid: string;
  setBid: (value: string) => void;
  onTrade: () => void;
}) {
  const dispatch = useGame((store) => store.dispatch);
  const current = game.players[game.current]!;
  if (game.phase === "turn") {
    return (
      <div className="btn-row">
        <button type="button" className="btn" data-testid="roll" onClick={() => dispatch({ type: "roll" })}>
          Lempar dadu
        </button>
        <button type="button" className="btn-line" onClick={onTrade}>Tawar</button>
      </div>
    );
  }
  if (game.phase === "jail") {
    return (
      <div className="btn-row">
        <button type="button" className="btn" onClick={() => dispatch({ type: "jail-pay" })}>
          Bayar {money(JAIL_FEE)}
        </button>
        {current.jailCards.chest > 0 ? (
          <button type="button" className="btn-line" onClick={() => dispatch({ type: "jail-card", deck: "chest" })}>
            Kartu Dana Umum
          </button>
        ) : null}
        {current.jailCards.chance > 0 ? (
          <button type="button" className="btn-line" onClick={() => dispatch({ type: "jail-card", deck: "chance" })}>
            Kartu Kesempatan
          </button>
        ) : null}
        <button type="button" className="btn-line" onClick={() => dispatch({ type: "jail-roll" })}>
          Lempar
        </button>
      </div>
    );
  }
  if (game.phase === "buy" && game.buyIndex != null) {
    const price = spacePrice(game.buyIndex);
    return (
      <div className="btn-row">
        <button type="button" className="btn" data-testid="buy" disabled={current.money < price} onClick={() => dispatch({ type: "buy" })}>
          Beli {money(price)}
        </button>
        <button type="button" className="btn-line" data-testid="decline" onClick={() => dispatch({ type: "decline" })}>
          Tolak, lelang
        </button>
      </div>
    );
  }
  if (game.phase === "auction" && game.auction) {
    const bidder = game.players.find((player) => player.id === game.auction?.turnId);
    const min = game.auction.bid === 0 ? 1 : game.auction.bid + 10;
    return (
      <div>
        <p className="quiet">
          {game.auction.leaderId
            ? `Penawaran ${money(game.auction.bid)} oleh ${game.players.find((player) => player.id === game.auction?.leaderId)?.name}`
            : "Belum ada tawaran."}{" "}
          Giliran {bidder?.name}.
        </p>
        {bidder && !bidder.isBot ? (
          <div className="btn-row">
            <input className="field" inputMode="numeric" aria-label="Nominal tawaran" value={bid} onChange={(event) => setBid(event.target.value)} />
            <button
              type="button"
              className="btn"
              onClick={() => dispatch({ type: "bid", amount: Number(bid) })}
            >
              Tawar min. {money(min)}
            </button>
            <button type="button" className="btn-line" onClick={() => dispatch({ type: "pass" })}>
              Lewat
            </button>
          </div>
        ) : (
          <p className="quiet">Komputer sedang mempertimbangkan tawaran.</p>
        )}
      </div>
    );
  }
  if (game.phase === "debt" && game.obligations[0]) {
    const due = game.obligations[0];
    const payer = game.players.find((player) => player.id === due.fromId);
    const payee =
      due.to.type === "player"
        ? game.players.find((player) => due.to.type === "player" && player.id === due.to.id)?.name
        : due.to.type === "pot"
          ? "Parkir Bebas"
          : "bank";
    return (
      <div>
        <p className="quiet">
          {payer?.name} berutang {money(due.amount)} kepada {payee} ({due.reason}). Jual bangunan atau hipotek dari petakmu.
        </p>
        <div className="btn-row">
          <button type="button" className="btn" disabled={!payer || payer.money < due.amount} onClick={() => dispatch({ type: "pay" })}>
            Bayar
          </button>
          <button type="button" className="btn-danger" onClick={() => dispatch({ type: "bankrupt" })}>
            Bangkrut
          </button>
        </div>
      </div>
    );
  }
  if (game.phase === "rolling" || game.phase === "animating") return <p className="quiet">Token sedang berjalan.</p>;
  return null;
}

function Detail({ game, index, actorId }: { game: GameState; index: number | null; actorId: string | null }) {
  const dispatch = useGame((store) => store.dispatch);
  if (index == null) return null;
  const space = SPACES[index];
  if (!space) return null;
  const deed = game.deeds[index];
  const owner = deed?.ownerId ? game.players.find((player) => player.id === deed.ownerId) : undefined;
  const mine = Boolean(actorId && deed?.ownerId === actorId);
  return (
    <section className="panel">
      <p className="eyebrow">
        {space.kind === "country" ? GROUP_META[space.group].label : space.kind === "company" ? "Perusahaan" : "Petak"}
      </p>
      <h2>{space.name}</h2>
      {owner ? <p className="quiet">Milik {owner.name}{deed?.mortgaged ? " · dihipotek" : ""}</p> : null}
      {!owner && (space.kind === "country" || space.kind === "company") ? <p className="quiet">Harga {money(space.price)}</p> : null}
      {space.kind === "country" ? (
        <table className="rent-table">
          <tbody>
            {["Dasar", "1 rumah", "2 rumah", "3 rumah", "4 rumah", "Hotel"].map((label, row) => (
              <tr key={label} data-now={deed && !deed.mortgaged && deed.ownerId && (deed.houses === row || (row === 0 && deed.houses === 0)) ? "yes" : "no"}>
                <td>{label}{row === 0 && deed?.ownerId && rentAmount(game, index) === space.rents[0] * 2 ? " ×2" : ""}</td>
                <td>{money(row === 0 && deed?.ownerId && rentAmount(game, index) === space.rents[0] * 2 ? space.rents[0] * 2 : space.rents[row] ?? 0)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : null}
      {space.kind === "country" ? <p className="quiet">Bangun {money(GROUP_META[space.group].house)} per rumah atau hotel. Harus merata.</p> : null}
      {space.kind === "company" ? (
        <table className="rent-table">
          <tbody>
            {COMPANY_RENT.slice(1).map((rent, row) => (
              <tr key={rent} data-now={deed?.ownerId && !deed.mortgaged && rentAmount(game, index) === rent ? "yes" : "no"}>
                <td>{row + 1} perusahaan</td>
                <td>{money(rent)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : null}
      {space.kind === "start" ? <p className="quiet">Lewati atau berhenti di sini: terima K200.</p> : null}
      {space.kind === "jail" ? <p className="quiet">Mampir saja, kecuali kamu sedang ditahan. Keluar dengan kembar, bayar K50, atau kartu.</p> : null}
      {space.kind === "parking" ? <p className="quiet">Ambil seluruh jackpot. Denda dan uang keluar penjara masuk ke sini.</p> : null}
      {space.kind === "goto-jail" ? <p className="quiet">Langsung ke penjara. Tidak mengambil gaji Mulai.</p> : null}
      {mine && deed ? (
        <div className="btn-row">
          {space.kind === "country" ? (
            <>
              <button type="button" className="btn" disabled={Boolean(buildBlock(game, index))} onClick={() => dispatch({ type: "build", index })}>
                Bangun
              </button>
              <button type="button" className="btn-line" disabled={Boolean(sellBlock(game, index))} onClick={() => dispatch({ type: "sell", index })}>
                Jual
              </button>
            </>
          ) : null}
          {deed.mortgaged ? (
            <button type="button" className="btn" onClick={() => dispatch({ type: "unmortgage", index })}>
              Tebus {money(unmortgageCost(index))}
            </button>
          ) : (
            <button type="button" className="btn-line" disabled={Boolean(mortgageBlock(game, index))} onClick={() => dispatch({ type: "mortgage", index })}>
              Hipotek {money(mortgageValue(index))}
            </button>
          )}
        </div>
      ) : null}
    </section>
  );
}

function TradeBox(props: {
  game: GameState;
  currentId: string;
  toId: string;
  setToId: (id: string) => void;
  give: number[];
  take: number[];
  giveMoney: number;
  takeMoney: number;
  setGiveMoney: (value: number) => void;
  setTakeMoney: (value: number) => void;
  toggleGive: (index: number) => void;
  toggleTake: (index: number) => void;
  onCancel: () => void;
  onSend: () => void;
}) {
  const others = props.game.players.filter((player) => !player.bankrupt && player.id !== props.currentId);
  const mine = ownedIndexes(props.game, props.currentId);
  const theirs = ownedIndexes(props.game, props.toId);
  return (
    <div>
      <label className="quiet" htmlFor="lawan">Lawan</label>
      <select id="lawan" className="field" value={props.toId} onChange={(event) => props.setToId(event.target.value)}>
        {others.map((player) => (
          <option key={player.id} value={player.id}>{player.name}</option>
        ))}
      </select>
      <p className="quiet">Tanahmu</p>
      <ul className="check-list">
        {mine.map((index) => {
          const deed = props.game.deeds[index];
          const blocked = (deed?.houses ?? 0) > 0;
          return (
            <li key={index}>
              <label>
                <input type="checkbox" disabled={blocked} checked={props.give.includes(index)} onChange={() => props.toggleGive(index)} />
                {SPACES[index]?.name}{blocked ? " (ada bangunan)" : ""}{deed?.mortgaged ? " · hipotek" : ""}
              </label>
            </li>
          );
        })}
      </ul>
      <p className="quiet">Tanah lawan</p>
      <ul className="check-list">
        {theirs.map((index) => {
          const deed = props.game.deeds[index];
          const blocked = (deed?.houses ?? 0) > 0;
          return (
            <li key={index}>
              <label>
                <input type="checkbox" disabled={blocked} checked={props.take.includes(index)} onChange={() => props.toggleTake(index)} />
                {SPACES[index]?.name}{blocked ? " (ada bangunan)" : ""}
              </label>
            </li>
          );
        })}
      </ul>
      <label className="quiet" htmlFor="give-money">Uang yang kamu beri</label>
      <input id="give-money" className="field" inputMode="numeric" value={props.giveMoney || ""} onChange={(event) => { props.setGiveMoney(Number(event.target.value) || 0); props.setTakeMoney(0); }} />
      <label className="quiet" htmlFor="take-money">Uang yang kamu minta</label>
      <input id="take-money" className="field" inputMode="numeric" value={props.takeMoney || ""} onChange={(event) => { props.setTakeMoney(Number(event.target.value) || 0); props.setGiveMoney(0); }} />
      <div className="btn-row">
        <button type="button" className="btn" onClick={props.onSend}>Kirim tawaran</button>
        <button type="button" className="btn-line" onClick={props.onCancel}>Tutup</button>
      </div>
    </div>
  );
}

function CardModal() {
  const game = useGame((store) => store.game);
  const dispatch = useGame((store) => store.dispatch);
  if (!game?.card) return null;
  const card = CARDS[game.card.id];
  if (!card) return null;
  return (
    <div className="modal-back">
      <article className="draw-card" data-deck={card.deck} role="dialog" aria-modal="true" aria-labelledby="card-title">
        <p className="eyebrow">{card.deck === "chest" ? "Dana Umum" : "Kesempatan"}</p>
        <h2 id="card-title">{card.title}</h2>
        <p>{card.text}</p>
        <button type="button" className="btn" data-testid="ack-card" onClick={() => dispatch({ type: "ack-card" })}>
          Lanjut
        </button>
      </article>
    </div>
  );
}

function TradeModal() {
  const game = useGame((store) => store.game);
  const dispatch = useGame((store) => store.dispatch);
  if (!game?.trade) return null;
  const offer = game.trade;
  const from = game.players.find((player) => player.id === offer.fromId);
  const to = game.players.find((player) => player.id === offer.toId);
  const names = (indexes: number[]) => indexes.map((index) => SPACES[index]?.name).filter(Boolean).join(", ") || "—";
  return (
    <Modal labelledBy="trade-title">
      <p className="eyebrow">Tukar</p>
      <h2 id="trade-title">{to?.name}, {from?.name} menawar.</h2>
      <p>Kamu memberi: {names(offer.give)}{offer.giveMoney ? ` + ${money(offer.giveMoney)}` : ""}</p>
      <p>Kamu menerima: {names(offer.take)}{offer.takeMoney ? ` + ${money(offer.takeMoney)}` : ""}</p>
      {to?.isBot ? <p className="quiet">Komputer sedang memutuskan.</p> : (
        <div className="btn-row">
          <button type="button" className="btn" onClick={() => dispatch({ type: "trade-accept" })}>Terima</button>
          <button type="button" className="btn-line" onClick={() => dispatch({ type: "trade-reject" })}>Tolak</button>
        </div>
      )}
    </Modal>
  );
}

function Rules({ onClose }: { onClose: () => void }) {
  return (
    <Modal labelledBy="rules-title">
      <p className="eyebrow">Cara main</p>
      <h2 id="rules-title">Aturan meja</h2>
      <ul className="rules">
        <li>Dua sampai enam pemain bergiliran di satu layar. Komputer bisa mengisi kursi kosong.</li>
        <li>Lempar dua dadu, jalan ke kiri dari Mulai. Kembar: lempar lagi. Tiga kali kembar: masuk penjara.</li>
        <li>Melewati atau berhenti di Mulai mendapat K200. Setiap pemain mulai dengan K1.500.</li>
        <li>Tanah kosong bisa dibeli. Kalau ditolak, petak dilelang. Sewa dibayar ke pemilik.</li>
        <li>Kelompok warna lengkap dan tidak dihipotek: sewa dasar kali dua. Bangun rumah merata, lalu hotel.</li>
        <li>Lima perusahaan — listrik, air, internet, stasiun, pelabuhan — sewanya naik sesuai jumlah yang kamu kuasai.</li>
        <li>Penjara: mampir gratis. Kalau ditahan, keluar dengan dadu kembar, bayar K50, atau kartu bebas. Gagal tiga kali wajib bayar lalu jalan.</li>
        <li>Denda, perbaikan, dan uang keluar penjara masuk Parkir Bebas. Siapa yang mampir mengambil jackpotnya.</li>
        <li>Bisa tukar tanah dan uang sebelum melempar, asal tidak ada bangunan. Hipotek setengah harga, tebus tambah 10%.</li>
        <li>Tidak bisa bayar utang sampai habis dijual: bangkrut. Pemain terakhir yang bertahan menang.</li>
      </ul>
      <button type="button" className="btn" onClick={onClose}>Tutup</button>
    </Modal>
  );
}

function Modal({ children, labelledBy }: { children: React.ReactNode; labelledBy?: string }) {
  return (
    <div className="modal-back">
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby={labelledBy}>
        {children}
      </div>
    </div>
  );
}
