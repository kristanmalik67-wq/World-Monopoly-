import { useState } from "react";
import { NAME_PRESETS, PLAYER_STYLES } from "@/game/board";
import { useGame } from "@/game/store";
import type { SetupPlayer } from "@/game/types";
import { TokenGlyph } from "./icons";

function initialSeats(): SetupPlayer[] {
  return [0, 1].map((index) => ({
    name: NAME_PRESETS[index] ?? `Pemain ${index + 1}`,
    human: true,
    color: PLAYER_STYLES[index]!.color,
    token: PLAYER_STYLES[index]!.token,
  }));
}

export function Setup() {
  const start = useGame((store) => store.start);
  const [seats, setSeats] = useState<SetupPlayer[]>(initialSeats);

  function update(index: number, patch: Partial<SetupPlayer>) {
    setSeats((current) => current.map((seat, seatIndex) => (seatIndex === index ? { ...seat, ...patch } : seat)));
  }

  function add() {
    setSeats((current) => {
      const used = new Set(current.map((seat) => seat.token));
      const style = PLAYER_STYLES.find((item) => !used.has(item.token));
      if (!style) return current;
      const index = PLAYER_STYLES.indexOf(style);
      return [
        ...current,
        {
          name: NAME_PRESETS[index] ?? `Pemain ${current.length + 1}`,
          human: true,
          color: style.color,
          token: style.token,
        },
      ];
    });
  }

  return (
    <main className="setup">
      <section className="setup-card">
        <p className="eyebrow">2–6 pemain · satu layar</p>
        <h1>Monopoli Dunia</h1>
        <p className="lede">
          Keliling 20 negara. Tiga Dana Umum, tiga Kesempatan, lima perusahaan, penjara, dan jackpot Parkir Bebas.
          Giliran bergantian di perangkat ini.
        </p>
        {seats.map((seat, index) => (
          <div className="seat" key={seat.token}>
            <span className="pawn pawn-lg" style={{ ["--pawn" as string]: seat.color }}>
              <TokenGlyph id={seat.token} size={16} />
            </span>
            <input
              className="field"
              aria-label={`Nama pemain ${index + 1}`}
              value={seat.name}
              maxLength={16}
              onChange={(event) => update(index, { name: event.target.value })}
            />
            <div className="seat-actions">
              <button type="button" className={seat.human ? "btn-line" : "btn"} onClick={() => update(index, { human: !seat.human })}>
                {seat.human ? "Manusia" : "Komputer"}
              </button>
              {seats.length > 2 ? (
                <button
                  type="button"
                  className="btn-quiet"
                  onClick={() => setSeats((current) => current.filter((_, seatIndex) => seatIndex !== index))}
                >
                  Hapus
                </button>
              ) : null}
            </div>
          </div>
        ))}
        <div className="btn-row">
          {seats.length < 6 ? (
            <button type="button" className="btn-line" onClick={add}>
              Tambah pemain
            </button>
          ) : null}
          <button type="button" className="btn" data-testid="start-game" onClick={() => start(seats)}>
            Mulai permainan
          </button>
        </div>
      </section>
    </main>
  );
}
